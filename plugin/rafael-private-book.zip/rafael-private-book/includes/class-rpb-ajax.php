<?php
/**
 * File: includes/class-rpb-ajax.php
 * The only way book text leaves the server: one chapter at a time, to a valid reader session,
 * with a CSRF token, rate limit, private/no-index headers and the reader's invisible fingerprint.
 * Also: saving reading position (so Rafael sees how far each reader got) and notes to the author.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Ajax {

	public static function init() {
		foreach ( array( 'chapter', 'progress', 'note' ) as $a ) {
			add_action( 'wp_ajax_rpb_' . $a, array( __CLASS__, $a ) );
			add_action( 'wp_ajax_nopriv_rpb_' . $a, array( __CLASS__, $a ) );
		}
	}

	private static function reader() {
		RPB_Bots::private_headers();
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || RPB_Bots::is_scraper() ) {
			wp_send_json( array( 'ok' => false ), 403 );
		}
		$r = RPB_Access::current();
		if ( ! $r ) {
			wp_send_json( array( 'ok' => false, 'error' => 'session' ), 401 );
		}
		$csrf = isset( $_POST['t'] ) ? sanitize_text_field( wp_unslash( $_POST['t'] ) ) : ''; // phpcs:ignore
		if ( ! hash_equals( RPB_Access::csrf( $r ), $csrf ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'csrf' ), 403 );
		}
		return $r;
	}

	private static function lang( $r ) {
		$l = isset( $_POST['lang'] ) ? sanitize_key( $_POST['lang'] ) : ''; // phpcs:ignore
		if ( ! in_array( $l, $r['langs'], true ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'lang' ), 403 );
		}
		return $l;
	}

	public static function chapter() {
		$r = self::reader();
		if ( ! RPB_Access::rate_ok( $r, 'ch', 60 ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'slow' ), 429 );
		}
		$lang = self::lang( $r );
		$pos  = isset( $_POST['pos'] ) ? (int) $_POST['pos'] : 0; // phpcs:ignore
		$sl   = RPB_DB::slang( $lang, $r['invite'] );
		if ( $r['invite'] && (int) $r['invite']['max_chapters'] > 0 && $pos > RPB_DB::max_pos( $sl, $r['invite']['max_chapters'] ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'locked' ), 403 );
		}
		if ( ! RPB_Access::rate_ok( $r, 'chh', 90, HOUR_IN_SECONDS ) || ! RPB_Access::rate_ok( $r, 'chd', 400, DAY_IN_SECONDS ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'slow' ), 429 );
		}
		$ch   = RPB_DB::chapter( $sl, $pos );
		if ( ! $ch ) {
			wp_send_json( array( 'ok' => false, 'error' => 'missing' ), 404 );
		}
		$meta = RPB_DB::meta( $sl );
		$iid  = $r['invite'] ? (int) $r['invite']['id'] : 0;
		$html = ( $iid && RPB_Settings::get( 'leak_trace' ) ) ? RPB_Access::mark_html( $ch['html'], $iid ) : $ch['html'];
		if ( $iid ) {
			$k = 'rpb_rd_' . md5( $iid . '|' . $lang . '|' . $ch['ckey'] . '|' . gmdate( 'Ymd' ) );
			if ( ! get_transient( $k ) ) {
				set_transient( $k, 1, DAY_IN_SECONDS );
				RPB_DB::log( $iid, 'chapter', $lang, $ch['title'] );
				RPB_Access::update_invite( $iid, array( 'reads_count' => (int) $r['invite']['reads_count'] + 1, 'last_seen' => RPB_DB::now() ) );
			}
		}
		wp_send_json(
			array(
				'ok'      => true,
				'version' => $meta['version'],
				'pos'     => (int) $ch['pos'],
				'key'     => $ch['ckey'],
				'kind'    => $ch['kind'],
				'part'    => $ch['part'],
				'title'   => $ch['title'],
				'html'    => $html,
			)
		);
	}

	public static function progress() {
		$r = self::reader();
		if ( ! $r['invite'] ) {
			wp_send_json( array( 'ok' => true ) );
		}
		if ( ! RPB_Access::rate_ok( $r, 'pg', 30 ) ) {
			wp_send_json( array( 'ok' => false ), 429 );
		}
		$lang  = self::lang( $r );
		// phpcs:disable WordPress.Security.NonceVerification
		$entry = array(
			'key'   => substr( sanitize_key( $_POST['key'] ?? '' ), 0, 40 ),
			'title' => mb_substr( sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ), 0, 120 ),
			'frac'  => max( 0, min( 1, (float) ( $_POST['frac'] ?? 0 ) ) ),
			'pct'   => max( 0, min( 100, round( (float) ( $_POST['pct'] ?? 0 ), 1 ) ) ),
			'at'    => time(),
		);
		$all = json_decode( (string) $r['invite']['progress'], true );
		$all = is_array( $all ) ? $all : array();
		$old = isset( $all[ $lang ]['max'] ) ? (float) $all[ $lang ]['max'] : 0;
		$entry['max']  = max( $old, $entry['pct'] );
		$all[ $lang ]  = $entry;
		$all['last']   = $lang;
		$meta          = RPB_DB::meta( RPB_DB::slang( $lang, $r['invite'] ) );
		RPB_Access::update_invite(
			$r['invite']['id'],
			array(
				'progress'     => wp_json_encode( $all ),
				'last_seen'    => RPB_DB::now(),
				'seen_version' => $lang . ':' . ( $meta ? ( $meta['ann'] ?? $meta['version'] ) : '' ),
			)
		);
		// phpcs:enable
		wp_send_json( array( 'ok' => true ) );
	}

	public static function note() {
		global $wpdb;
		$r = self::reader();
		if ( ! RPB_Access::rate_ok( $r, 'note', 6 ) ) {
			wp_send_json( array( 'ok' => false, 'error' => 'slow' ), 429 );
		}
		$lang = self::lang( $r );
		// phpcs:disable WordPress.Security.NonceVerification
		$body = trim( sanitize_textarea_field( wp_unslash( $_POST['body'] ?? '' ) ) );
		if ( '' === $body ) {
			wp_send_json( array( 'ok' => false, 'error' => 'empty' ), 400 );
		}
		$wpdb->insert(
			RPB_DB::t( 'notes' ),
			array(
				'invite_id' => $r['invite'] ? (int) $r['invite']['id'] : 0,
				'at'        => RPB_DB::now(),
				'lang'      => $lang,
				'ckey'      => substr( sanitize_key( $_POST['key'] ?? '' ), 0, 40 ),
				'chapter'   => mb_substr( sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ), 0, 255 ),
				'page'      => (int) ( $_POST['page'] ?? 0 ),
				'pages'     => (int) ( $_POST['pages'] ?? 0 ),
				'pct'       => min( 100, max( 0, round( (float) ( $_POST['pct'] ?? 0 ), 1 ) ) ),
				'world'     => in_array( $_POST['world'] ?? '', array( 'a', 'd', 'b' ), true ) ? $_POST['world'] : '',
				'quote'     => mb_substr( sanitize_text_field( wp_unslash( $_POST['quote'] ?? '' ) ), 0, 400 ),
				'body'      => mb_substr( $body, 0, 8000 ),
			)
		);
		$where = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) ) . ' · עמוד ' . (int) ( $_POST['page'] ?? 0 ) . "\nהעמוד מתחיל ב: «" . mb_substr( sanitize_text_field( wp_unslash( $_POST['quote'] ?? '' ) ), 0, 400 ) . '»';
		// phpcs:enable
		if ( $r['invite'] ) {
			RPB_DB::log( $r['invite']['id'], 'note', $lang, mb_substr( $body, 0, 80 ) );
			RPB_Notify::note_to_author( $r['invite'], $body . "\n\n" . $where );
		}
		wp_send_json( array( 'ok' => true ) );
	}
}
