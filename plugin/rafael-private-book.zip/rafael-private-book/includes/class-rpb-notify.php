<?php
/**
 * File: includes/class-rpb-notify.php
 * Landing-page forms (early-reader access requests + launch-price pre-registration),
 * emails to Rafael, "the book was updated" messages to readers (email + ready WhatsApp links).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Notify {

	/** Saves a landing-page form. Returns true when stored. */
	public static function handle_request( $lang ) {
		global $wpdb;
		// phpcs:disable WordPress.Security.NonceVerification
		if ( ! empty( $_POST['website'] ) ) { // honeypot: humans never fill it
			return true;
		}
		$t0 = isset( $_POST['t0'] ) ? (int) $_POST['t0'] : 0;
		if ( $t0 && time() - $t0 < 3 ) { // filled faster than a human can
			return false;
		}
		$ipkey = 'rpb_req_' . md5( RPB_Access::ip() );
		$n     = (int) get_transient( $ipkey );
		if ( $n >= 6 ) {
			return 'busy'; // too many sign-ups from this address in the last hour
		}
		set_transient( $ipkey, $n + 1, HOUR_IN_SECONDS );

		$kind  = ( 'launch' === ( $_POST['kind'] ?? '' ) ) ? 'launch' : 'access';
		$name  = mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), 0, 190 );
		$raw   = trim( (string) wp_unslash( $_POST['email'] ?? '' ) );
		$email = is_email( $raw ) ? sanitize_email( $raw ) : '';
		$phone = (string) wp_unslash( $_POST['phone'] ?? '' );
		if ( ! $email && '' === trim( $phone ) && preg_match( '/^[0-9+\-\s()]{7,}$/', $raw ) ) {
			$phone = $raw; // "email or phone" field
		}
		$phone = mb_substr( preg_replace( '/[^0-9+\-\s]/', '', $phone ), 0, 40 );
		$msg   = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ), 0, 3000 );
		$cons  = ! empty( $_POST['consent'] ) ? 1 : 0;
		// phpcs:enable
		if ( '' === $name || ( '' === $email && '' === trim( $phone ) ) ) {
			return false;
		}
		if ( empty( $_POST['privacy'] ) ) { // phpcs:ignore -- privacy notice acknowledged (Israeli Privacy Protection Law, Amendment 13)
			return false;
		}
		$src = array();
		foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'ref' ) as $u ) {
			if ( ! empty( $_POST[ $u ] ) ) { // phpcs:ignore
				$src[] = $u . '=' . substr( sanitize_text_field( wp_unslash( $_POST[ $u ] ) ), 0, 80 ); // phpcs:ignore
			}
		}
		if ( $src ) {
			$msg = trim( $msg . "\n[" . implode( ' ', $src ) . ']' );
		}
		$wpdb->insert(
			RPB_DB::t( 'requests' ),
			array(
				'at'      => RPB_DB::now(),
				'kind'    => $kind,
				'name'    => $name,
				'contact' => $email ? $email : $phone,
				'email'   => $email,
				'phone'   => trim( $phone ),
				'consent' => $cons,
				'lang'    => $lang,
				'message' => $msg,
				'status'  => 'new',
				'ip'      => RPB_Access::ip(),
			)
		);
		if ( RPB_Settings::get( 'notify_requests' ) ) {
			$what = 'launch' === $kind ? 'נרשם/ה למחיר ההשקה' : 'ביקש/ה גישה לקריאה מוקדמת';
			wp_mail(
				get_option( 'admin_email' ),
				'חצי סנטימטר: ' . $name . ' ' . $what,
				"שם: $name\nמייל: $email\nטלפון: $phone\nשפה: $lang\n\n$msg\n\nלניהול: " . admin_url( 'admin.php?page=rpb-requests' )
			);
		}
		return true;
	}

	public static function note_to_author( $invite, $body ) {
		if ( ! RPB_Settings::get( 'notify_requests' ) ) {
			return;
		}
		wp_mail(
			get_option( 'admin_email' ),
			'חצי סנטימטר: הערה חדשה מ' . ( $invite['name'] ? $invite['name'] : 'קורא/ת' ),
			$body . "\n\nכל ההערות: " . admin_url( 'admin.php?page=rpb-notes' )
		);
	}

	/* ---------- update messages to readers ---------- */

	public static function default_message( $lang ) {
		if ( 'en' === $lang ) {
			return "Hi {name},\n\nThere's a new version of \"Half an Inch\", rewritten after notes from professional writers.\nYour personal link opens it right where you stopped:\n{link}\n\nThank you for reading,\nRafael";
		}
		return "היי {name},\n\nיש גרסה חדשה של \"חצי סנטימטר\", אחרי עריכה בעקבות ביקורת של סופרים.\nהקישור האישי שלך פותח אותה בדיוק איפה שעצרת:\n{link}\n\nתודה שאת/ה קורא/ת,\nרפאל";
	}

	public static function fill( $tpl, $inv ) {
		$name = $inv['name'] ? $inv['name'] : ( 'en' === $inv['lang'] ? 'there' : '' );
		$out  = strtr( $tpl, array( '{name}' => $name, '{link}' => RPB_Settings::invite_url( $inv['token'] ) ) );
		return preg_replace( '/^(היי|Hi) ,/mu', '$1,', $out );
	}

	public static function whatsapp_url( $inv, $text ) {
		$phone = preg_replace( '/\D/', '', (string) $inv['phone'] );
		if ( $phone && '0' === $phone[0] ) {
			$phone = '972' . substr( $phone, 1 ); // Israeli local number -> international
		}
		return 'https://wa.me/' . $phone . '?text=' . rawurlencode( $text );
	}

	/** Emails every active reader that has an email. Returns [sent, failed, skipped]. */
	public static function send_update( $subject_he, $subject_en, $body_he, $body_en ) {
		global $wpdb;
		$t    = RPB_DB::t( 'invites' );
		$rows = $wpdb->get_results( "SELECT * FROM $t WHERE revoked = 0", ARRAY_A ); // phpcs:ignore
		$sent = 0;
		$fail = 0;
		$skip = 0;
		foreach ( $rows as $inv ) {
			if ( RPB_Access::invite_problem( $inv ) || ! is_email( $inv['email'] ) ) {
				++$skip;
				continue;
			}
			$en = ( 'en' === $inv['lang'] );
			$ok = wp_mail( $inv['email'], $en ? $subject_en : $subject_he, self::fill( $en ? $body_en : $body_he, $inv ) );
			$ok ? ++$sent : ++$fail;
			if ( $ok ) {
				RPB_DB::log( $inv['id'], 'mailed', $en ? 'en' : 'he', $en ? $subject_en : $subject_he );
			}
		}
		return array( $sent, $fail, $skip );
	}
}
