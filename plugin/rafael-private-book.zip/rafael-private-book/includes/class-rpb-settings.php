<?php
/**
 * File: includes/class-rpb-settings.php
 * Plugin settings with defaults, plus the site secrets (cookie signing key and the book "update key").
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Settings {

	public static function defaults() {
		return array(
			'slug'              => 'book',
			'landing_index'     => 0,   // allow search engines to index the landing page (book text is never indexable)
			'landing_requests'  => 1,   // "ask for access" form on the landing page
			'block_ai_sitewide' => 0,   // 1 = robots.txt + 403 for AI crawlers on the WHOLE site (off: only the book is blocked, the rest of the site is untouched)
			'protect_copy'      => 1,   // no select / copy / print / right click in the reader
			'watermark'         => 1,   // reader's name faintly on every page
			'leak_trace'        => 1,   // invisible per-reader fingerprint inside the text
			'max_devices'       => 3,
			'session_days'      => 180,
			'notify_requests'   => 1,   // email Rafael when someone asks for access
			'pull_url'          => '',  // optional: address of an encrypted book package to check every hour
			'author_he'         => 'רפאל עמר',
			'author_en'         => 'Rafael Amar',
			'eyebrow_he'        => 'רומן · בהשראת סיפור אמיתי',
			'eyebrow_en'        => 'A novel · Inspired by a true story',
			'tagline_he'        => 'אחד משני הסיפורים בספר הזה קרה באמת.',
			'tagline_en'        => 'One of the two stories in this book really happened.',
			'blurb_he'          => "קיץ 2000. גבריאל, בן עשרים ושתיים וחצי, איש ענק על קטנוע קטן, נכנס לצ'אט וקורא הודעה אחת: \"אני מחפשת מלאך\".\n\nהאצבע שלו מרחפת מעל כפתור \"התנתק\".\n\nאם היא זזה חצי סנטימטר, הוא לא פוגש את נוגה לעולם. אם היא לא זזה, הוא פוגש אותה, ואחר כך גם את לולה, האישה שתשנה את שניהם.\n\nשני קווי זמן. שני חיים שלמים. דייט עיוור מול קפה לונדון, שמלה ורודה בלי כתפיות, כלוב זהב בנחלה של איש עשיר ומפחיד, ואהבה שלא מוכנה להיכנס לשום מגירה.\n\n\"חצי סנטימטר\" הוא רומן סוחף, סקסי ומצחיק על החלטה אחת קטנה שמשנה הכול, ועל השאלה שכולנו שאלנו פעם בשתיים בלילה: מה היה קורה אילו.",
			'blurb_en'          => "Summer, 2000. Gavriel is twenty-two and a half, a giant on a tiny scooter, when he logs into a chat room and reads a single message: \"I'm looking for an angel.\"\n\nHis finger hovers over Disconnect.\n\nHalf an inch one way, and he never meets Noga. Half an inch the other, and he meets her, and later Lola, the woman who will change them both.\n\nTwo timelines. Two whole lives. A blind date outside Cafe London, a pink strapless dress, a gilded cage on a rich and frightening man's farm, and a love that refuses to fit in any box.\n\nHalf an Inch is a sweeping, sexy, funny novel about one tiny decision that changes everything, and about the question all of us have asked at two in the morning: what if?",
			'quotes_he'         => '', // one per line: quote | name   (real quotes only)
			'quotes_en'         => '',
			'launch_he'         => 'הנרשמים מראש יקבלו מחיר השקה מוזל ויהיו הראשונים לדעת כשהספר יוצא.',
			'launch_en'         => 'Early sign-ups get a special launch price and are the first to know when the book is out.',
			'comps_he'          => 'למי שאהב את קולין הובר, את מריאן קיז ואת "דלתות מסתובבות".',
			'comps_en'          => 'For readers who loved Colleen Hoover, Marian Keyes and Sliding Doors.',
			'adult_he'          => 'רומן למבוגרים: כולל תוכן מיני ומערכת יחסים לא שגרתית.',
			'adult_en'          => 'A novel for adults: includes sexual content and an unconventional relationship.',
			'faq_he'            => "מתי הספר יוצא? | בקרוב. הנרשמים מראש ישמעו ראשונים, עם מחיר ההשקה.\nבאילו פורמטים? | ספר מודפס וספר דיגיטלי.\nיש גרסה באנגלית? | כן, Half an Inch, בתרגום מלא.\nאיך מסירים את עצמי מהרשימה? | בלחיצה על הקישור שבכל הודעה, או במייל לכתובת שבמדיניות הפרטיות.",
			'faq_en'            => "When is the book out? | Soon. Early sign-ups hear first, with the launch price.\nWhich formats? | Print and ebook.\nIs it in English? | Yes: Half an Inch, a full translation.\nHow do I unsubscribe? | Use the link in any message, or email the address in the privacy policy.",
			'contact_email'     => '',
			'status_he'         => 'הספר בשלב קריאה מוקדמת, לפני יציאתו לאור. הקריאה בהזמנה אישית בלבד.',
			'status_en'         => 'The book is in early private reading, before publication. Reading is by personal invitation only.',
		);
	}

	public static function all() {
		$s = get_option( 'rpb_settings' );
		return wp_parse_args( is_array( $s ) ? $s : array(), self::defaults() );
	}

	public static function get( $key ) {
		$s = self::all();
		return isset( $s[ $key ] ) ? $s[ $key ] : null;
	}

	public static function save( array $new ) {
		$s = array_merge( self::all(), $new );
		update_option( 'rpb_settings', $s, true );
	}

	public static function contact_email() {
		$e = (string) self::get( 'contact_email' );
		return is_email( $e ) ? $e : (string) get_option( 'admin_email' );
	}

	public static function slug() {
		$slug = sanitize_title( (string) self::get( 'slug' ) );
		return $slug ? $slug : 'book';
	}

	public static function ensure_secrets() {
		if ( ! get_option( 'rpb_cookie_key' ) ) {
			update_option( 'rpb_cookie_key', self::random( 48 ), false );
		}
		if ( ! get_option( 'rpb_update_key' ) ) {
			update_option( 'rpb_update_key', self::random( 32 ), false );
		}
	}

	public static function cookie_key() {
		$k = get_option( 'rpb_cookie_key' );
		return $k ? $k : wp_salt( 'auth' );
	}

	public static function update_key() {
		return (string) get_option( 'rpb_update_key' );
	}

	/** URL-safe random string. */
	public static function random( $bytes ) {
		return rtrim( strtr( base64_encode( random_bytes( $bytes ) ), '+/', '-_' ), '=' );
	}

	/** Address of the reader / landing page. */
	public static function book_url( $args = array() ) {
		if ( get_option( 'permalink_structure' ) ) {
			$url = home_url( '/' . self::slug() . '/' );
		} else {
			$url = add_query_arg( 'rpb', '1', home_url( '/' ) );
		}
		return $args ? add_query_arg( $args, $url ) : $url;
	}

	public static function invite_url( $token ) {
		return self::book_url( array( 'k' => $token ) );
	}
}
