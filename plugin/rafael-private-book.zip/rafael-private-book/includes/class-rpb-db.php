<?php
/**
 * File: includes/class-rpb-db.php
 * Database tables (book text, invites, access log, access requests), install/upgrade, cleanup.
 * The book text lives ONLY in a private database table: never in posts, media, REST, feeds or sitemaps.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_DB {

	public static function t( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'rpb_' . $name;
	}

	public static function activate() {
		self::install();
		RPB_Settings::ensure_secrets();
		if ( ! wp_next_scheduled( 'rpb_daily' ) ) {
			wp_schedule_event( time() + 300, 'daily', 'rpb_daily' );
		}
		self::schedule_pull();
	}

	/** Check the update address every 10 minutes (a cheap request: unchanged files answer 304). */
	public static function schedule_pull() {
		$next = wp_get_scheduled_event( 'rpb_pull' );
		if ( $next && 'rpb_10min' === $next->schedule ) {
			return;
		}
		wp_clear_scheduled_hook( 'rpb_pull' );
		wp_schedule_event( time() + 60, 'rpb_10min', 'rpb_pull' );
	}

	public static function schedules( $s ) {
		$s['rpb_10min'] = array( 'interval' => 600, 'display' => 'Every 10 minutes (book updates)' );
		return $s;
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'rpb_daily' );
		wp_clear_scheduled_hook( 'rpb_pull' );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'rpb_db_version' ) !== RPB_DB_VERSION ) {
			self::quiet_upgrade();
			self::install();
			RPB_Settings::ensure_secrets();
			self::schedule_pull();
		}
		add_action( 'rpb_daily', array( __CLASS__, 'cleanup' ) );
	}

	/** 1.1.1: the version on the site when upgrading is treated as a silent update of the previous one. */
	public static function quiet_upgrade() {
		$log = get_option( 'rpb_changelog' );
		$log = is_array( $log ) ? $log : array();
		foreach ( array( 'he', 'en' ) as $l ) {
			$m = get_option( 'rpb_book_' . $l );
			if ( ! is_array( $m ) || isset( $m['quiet'] ) ) {
				continue;
			}
			$q = array( $m['version'] );
			foreach ( $log as $c ) {
				if ( ( $c['lang'] ?? '' ) === $l && ( $c['version'] ?? '' ) !== $m['version'] ) {
					array_unshift( $q, $c['version'] );
					break;
				}
			}
			$m['quiet'] = $q;
			update_option( 'rpb_book_' . $l, $m, false );
		}
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();

		dbDelta( 'CREATE TABLE ' . self::t( 'chapters' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			lang varchar(5) NOT NULL,
			version varchar(40) NOT NULL,
			pos int(11) NOT NULL,
			ckey varchar(40) NOT NULL,
			kind varchar(10) NOT NULL DEFAULT 'chapter',
			part varchar(190) NOT NULL DEFAULT '',
			title varchar(255) NOT NULL DEFAULT '',
			words int(11) NOT NULL DEFAULT 0,
			html longtext NOT NULL,
			PRIMARY KEY  (id),
			KEY lang_version (lang,version,pos)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'invites' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			token varchar(64) NOT NULL,
			name varchar(190) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '',
			lang varchar(5) NOT NULL DEFAULT 'he',
			note text NULL,
			max_devices smallint(5) NOT NULL DEFAULT 3,
			max_chapters smallint(5) NOT NULL DEFAULT 0,
			devices longtext NULL,
			expires_at datetime NULL,
			revoked tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			first_open datetime NULL,
			last_seen datetime NULL,
			opens int(11) NOT NULL DEFAULT 0,
			reads_count int(11) NOT NULL DEFAULT 0,
			progress longtext NULL,
			seen_version varchar(90) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			UNIQUE KEY token (token)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'log' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invite_id bigint(20) unsigned NOT NULL DEFAULT 0,
			at datetime NOT NULL,
			event varchar(20) NOT NULL,
			lang varchar(5) NOT NULL DEFAULT '',
			detail varchar(190) NOT NULL DEFAULT '',
			ip varchar(64) NOT NULL DEFAULT '',
			ua varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY invite_id (invite_id),
			KEY at (at)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'requests' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			at datetime NOT NULL,
			kind varchar(10) NOT NULL DEFAULT 'access',
			name varchar(190) NOT NULL DEFAULT '',
			contact varchar(190) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '',
			consent tinyint(1) NOT NULL DEFAULT 0,
			lang varchar(5) NOT NULL DEFAULT 'he',
			message text NULL,
			status varchar(12) NOT NULL DEFAULT 'new',
			ip varchar(64) NOT NULL DEFAULT '',
			PRIMARY KEY  (id)
		) $c;" );

		dbDelta( 'CREATE TABLE ' . self::t( 'notes' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			invite_id bigint(20) unsigned NOT NULL DEFAULT 0,
			at datetime NOT NULL,
			lang varchar(5) NOT NULL DEFAULT '',
			ckey varchar(40) NOT NULL DEFAULT '',
			chapter varchar(255) NOT NULL DEFAULT '',
			page int(11) NOT NULL DEFAULT 0,
			pages int(11) NOT NULL DEFAULT 0,
			pct float NOT NULL DEFAULT 0,
			world varchar(4) NOT NULL DEFAULT '',
			quote varchar(400) NOT NULL DEFAULT '',
			body text NOT NULL,
			done tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY invite_id (invite_id)
		) $c;" );

		update_option( 'rpb_db_version', RPB_DB_VERSION, false );
	}

	/** Daily: keep the log to 180 days / 20,000 rows. */
	public static function cleanup() {
		global $wpdb;
		$log = self::t( 'log' );
		$wpdb->query( $wpdb->prepare( "DELETE FROM $log WHERE at < %s", gmdate( 'Y-m-d H:i:s', time() - 180 * DAY_IN_SECONDS ) ) ); // phpcs:ignore
		$cut = (int) $wpdb->get_var( "SELECT id FROM $log ORDER BY id DESC LIMIT 1 OFFSET 20000" ); // phpcs:ignore
		if ( $cut ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $log WHERE id <= %d", $cut ) ); // phpcs:ignore
		}
	}

	public static function now() {
		return current_time( 'mysql', true ); // UTC
	}

	/* ---------- book ---------- */

	public static function meta( $lang ) {
		$m = get_option( 'rpb_book_' . $lang );
		return is_array( $m ) ? $m : null;
	}

	public static function languages() {
		$out = array();
		foreach ( array( 'he', 'en' ) as $l ) {
			if ( self::meta( $l ) ) {
				$out[] = $l;
			}
		}
		return $out;
	}

	public static function toc( $lang ) {
		global $wpdb;
		$m = self::meta( $lang );
		if ( ! $m ) {
			return array();
		}
		$t = self::t( 'chapters' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT pos, ckey, kind, part, title, words FROM $t WHERE lang = %s AND version = %s ORDER BY pos ASC", $lang, $m['version'] ), ARRAY_A ); // phpcs:ignore
	}

	/** Highest chapter position a reader may open (0 chapters = whole book). Front matter always counts as allowed. */
	public static function max_pos( $lang, $max_chapters ) {
		$toc = self::toc( $lang );
		if ( ! $toc ) {
			return -1;
		}
		$max_chapters = (int) $max_chapters;
		if ( $max_chapters <= 0 ) {
			return (int) end( $toc )['pos'];
		}
		$n = 0;
		$last = 0;
		foreach ( $toc as $r ) {
			if ( 'chapter' === $r['kind'] ) {
				if ( ++$n > $max_chapters ) {
					break;
				}
			}
			$last = (int) $r['pos'];
		}
		return $last;
	}

	public static function chapter( $lang, $pos ) {
		global $wpdb;
		$m = self::meta( $lang );
		if ( ! $m ) {
			return null;
		}
		$t = self::t( 'chapters' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT pos, ckey, kind, part, title, words, html FROM $t WHERE lang = %s AND version = %s AND pos = %d", $lang, $m['version'], $pos ), ARRAY_A ); // phpcs:ignore
	}

	/* ---------- log ---------- */

	public static function log( $invite_id, $event, $lang = '', $detail = '' ) {
		global $wpdb;
		$wpdb->insert(
			self::t( 'log' ),
			array(
				'invite_id' => (int) $invite_id,
				'at'        => self::now(),
				'event'     => substr( $event, 0, 20 ),
				'lang'      => substr( (string) $lang, 0, 5 ),
				'detail'    => mb_substr( (string) $detail, 0, 190 ),
				'ip'        => RPB_Access::ip(),
				'ua'        => mb_substr( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '', 0, 255 ),
			)
		);
	}
}
