<?php
/**
 * File: includes/class-rpb-admin.php
 * wp-admin screens ("הספר שלי"): readers & personal links, book updates, launch sign-ups & access requests,
 * readers' notes, access log, "the book was updated" messages, settings and the leak tracer.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Admin {

	const CAP = 'manage_options';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_rpb_admin', array( __CLASS__, 'handle' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( RPB_FILE ), array( __CLASS__, 'links' ) );
	}

	public static function links( $l ) {
		array_unshift( $l, '<a href="' . esc_url( admin_url( 'admin.php?page=rpb' ) ) . '">קוראים וקישורים</a>' );
		return $l;
	}

	public static function menu() {
		$new = self::count_new();
		$badge = $new ? ' <span class="awaiting-mod">' . (int) $new . '</span>' : '';
		add_menu_page( 'הספר שלי', 'הספר שלי' . $badge, self::CAP, 'rpb', array( __CLASS__, 'page_readers' ), 'dashicons-book-alt', 3 );
		add_submenu_page( 'rpb', 'קוראים וקישורים', 'קוראים וקישורים', self::CAP, 'rpb', array( __CLASS__, 'page_readers' ) );
		add_submenu_page( 'rpb', 'עדכון הספר', 'עדכון הספר', self::CAP, 'rpb-update', array( __CLASS__, 'page_update' ) );
		add_submenu_page( 'rpb', 'נרשמים ובקשות', 'נרשמים ובקשות' . $badge, self::CAP, 'rpb-requests', array( __CLASS__, 'page_requests' ) );
		add_submenu_page( 'rpb', 'הערות קוראים', 'הערות קוראים', self::CAP, 'rpb-notes', array( __CLASS__, 'page_notes' ) );
		add_submenu_page( 'rpb', 'הודעה לכל הקוראים', 'הודעה לכל הקוראים', self::CAP, 'rpb-notify', array( __CLASS__, 'page_notify' ) );
		add_submenu_page( 'rpb', 'יומן כניסות', 'יומן כניסות', self::CAP, 'rpb-log', array( __CLASS__, 'page_log' ) );
		add_submenu_page( 'rpb', 'הגדרות ועמוד נחיתה', 'הגדרות ועמוד נחיתה', self::CAP, 'rpb-settings', array( __CLASS__, 'page_settings' ) );
	}

	private static function count_new() {
		global $wpdb;
		$t = RPB_DB::t( 'requests' );
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE status = 'new'" ); // phpcs:ignore
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'rpb' ) ) {
			return;
		}
		wp_enqueue_style( 'rpb-admin', RPB_URL . 'assets/admin.css', array(), RPB_VERSION );
		wp_enqueue_script( 'rpb-admin', RPB_URL . 'assets/admin.js', array(), RPB_VERSION, true );
	}

	/* ---------- helpers ---------- */

	private static function form_open( $do, $extra = '' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" ' . $extra . '>'; // phpcs:ignore
		echo '<input type="hidden" name="action" value="rpb_admin"><input type="hidden" name="do" value="' . esc_attr( $do ) . '">';
		wp_nonce_field( 'rpb_admin' );
	}

	private static function btn_post( $do, $id, $label, $class = 'button-link', $confirm = '' ) {
		self::form_open( $do, 'class="inline"' . ( $confirm ? ' data-confirm="' . esc_attr( $confirm ) . '"' : '' ) );
		echo '<input type="hidden" name="id" value="' . (int) $id . '"><button class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	}

	private static function back( $page, $args = array() ) {
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . $page ) ) );
		exit;
	}

	private static function notice() {
		$m = get_transient( 'rpb_notice_' . get_current_user_id() );
		if ( $m ) {
			delete_transient( 'rpb_notice_' . get_current_user_id() );
			echo '<div class="notice notice-' . esc_attr( $m[0] ) . ' is-dismissible"><p>' . wp_kses_post( $m[1] ) . '</p></div>';
		}
	}

	private static function flash( $type, $html ) {
		set_transient( 'rpb_notice_' . get_current_user_id(), array( $type, $html ), 120 );
	}

	private static function dt( $mysql_utc ) {
		if ( ! $mysql_utc ) {
			return '—';
		}
		$ts = strtotime( $mysql_utc . ' UTC' );
		return esc_html( wp_date( 'j.n.y H:i', $ts ) );
	}

	private static function lang_label( $l ) {
		return array( 'he' => 'עברית', 'en' => 'אנגלית', 'both' => 'עברית + אנגלית' )[ $l ] ?? $l;
	}

	private static function header( $title, $sub = '' ) {
		echo '<div class="wrap rpb"><h1 class="rpb-h">' . esc_html( $title ) . '</h1>';
		$m   = RPB_DB::meta( 'he' );
		$m   = $m ? $m : RPB_DB::meta( 'en' );
		$gen = ( $m && ! empty( $m['generated'] ) ) ? wp_date( 'j.n.y H:i', strtotime( $m['generated'] ) ) : 'עוד לא הועלה';
		echo '<p class="rpb-ver">גרסת התוסף: <b dir="ltr">' . esc_html( RPB_VERSION ) . '</b> · הספר באתר נבנה ב־<b dir="ltr">' . esc_html( $gen ) . '</b></p>';
		if ( $sub ) {
			echo '<p class="rpb-sub">' . wp_kses_post( $sub ) . '</p>';
		}
		self::notice();
	}

	private static function copy_field( $value, $label = 'העתקה' ) {
		echo '<span class="rpb-copy"><input type="text" readonly value="' . esc_attr( $value ) . '" dir="ltr"><button type="button" class="button" data-copy>' . esc_html( $label ) . '</button></span>';
	}

	/* ---------- pages ---------- */

	public static function page_readers() {
		global $wpdb;
		$t     = RPB_DB::t( 'invites' );
		$edit  = isset( $_GET['edit'] ) ? RPB_Access::invite( (int) $_GET['edit'] ) : null; // phpcs:ignore
		$rows  = $wpdb->get_results( "SELECT * FROM $t ORDER BY revoked ASC, id DESC", ARRAY_A ); // phpcs:ignore
		$langs = RPB_DB::languages();
		self::header( 'קוראים וקישורים אישיים', 'כל קורא מקבל קישור משלו. הקישור פותח את הספר רק במספר המכשירים שקבעת, ואפשר לבטל אותו בכל רגע. <a href="' . esc_url( RPB_Settings::book_url( array( 'landing' => 1 ) ) ) . '" target="_blank">עמוד הנחיתה</a> · <a href="' . esc_url( RPB_Settings::book_url() ) . '" target="_blank">לקרוא את הספר בעצמך (תצוגה מקדימה)</a>' );
		if ( ! $langs ) {
			echo '<div class="notice notice-warning"><p>עוד לא הועלה ספר. <a href="' . esc_url( admin_url( 'admin.php?page=rpb-update' ) ) . '">להעלות את חבילת הספר</a></p></div>';
		}
		$new = isset( $_GET['new'] ) ? RPB_Access::invite( (int) $_GET['new'] ) : null; // phpcs:ignore
		if ( $new ) {
			$url = RPB_Settings::invite_url( $new['token'] );
			echo '<div class="rpb-card rpb-new"><h2>הקישור של ' . esc_html( $new['name'] ? $new['name'] : 'הקורא/ת' ) . ' מוכן</h2>';
			self::copy_field( $url, 'העתקת הקישור' );
			$msg = RPB_Notify::fill( 'en' === $new['lang'] ? "Hi {name},\nI'd love you to read my novel \"Half an Inch\" before it comes out. Here's your personal link (please don't forward it):\n{link}\n\nRafael" : "היי {name},\nאשמח שתקרא/י את הרומן שלי \"חצי סנטימטר\" לפני שהוא יוצא לאור. זה הקישור האישי שלך (בבקשה לא להעביר הלאה):\n{link}\n\nרפאל", $new );
			echo ' <a class="button button-primary rpb-wa" target="_blank" rel="noopener" href="' . esc_url( RPB_Notify::whatsapp_url( $new, $msg ) ) . '">שליחה בוואטסאפ</a>';
			if ( $new['email'] ) {
				echo ' <a class="button" href="' . esc_url( 'mailto:' . rawurlencode( $new['email'] ) . '?subject=' . rawurlencode( 'en' === $new['lang'] ? 'Half an Inch: your personal link' : 'חצי סנטימטר: הקישור האישי שלך' ) . '&body=' . rawurlencode( $msg ) ) . '">שליחה במייל</a>';
			}
			echo '</div>';
		}

		// create / edit form
		$e = $edit ? $edit : array( 'id' => 0, 'name' => '', 'email' => '', 'phone' => '', 'lang' => 'both', 'note' => '', 'max_devices' => RPB_Settings::get( 'max_devices' ), 'max_chapters' => 0, 'expires_at' => '' );
		echo '<div class="rpb-card"><h2>' . ( $edit ? 'עריכת קורא' : 'קישור חדש' ) . '</h2>';
		self::form_open( $edit ? 'invite_update' : 'invite_create', 'class="rpb-grid"' );
		echo '<input type="hidden" name="id" value="' . (int) $e['id'] . '">';
		echo '<label>שם הקורא <input name="name" value="' . esc_attr( $e['name'] ) . '" placeholder="למשל: ציון בן־שטרית"><small>יופיע בברכה ובסימן המים</small></label>';
		echo '<label>שפה <select name="lang">';
		foreach ( array( 'he', 'en', 'both' ) as $l ) {
			echo '<option value="' . esc_attr( $l ) . '"' . selected( $e['lang'], $l, false ) . '>' . esc_html( self::lang_label( $l ) ) . '</option>';
		}
		echo '</select></label>';
		echo '<label>טלפון (לוואטסאפ) <input name="phone" dir="ltr" value="' . esc_attr( $e['phone'] ) . '" placeholder="050-0000000"></label>';
		echo '<label>מייל (להודעות עדכון) <input name="email" type="email" dir="ltr" value="' . esc_attr( $e['email'] ) . '"></label>';
		echo '<label>מספר מכשירים <input name="max_devices" type="number" min="0" max="50" value="' . (int) $e['max_devices'] . '"><small>0 = ללא הגבלה</small></label>';
		echo '<label>כמה פרקים מותר לקרוא <input name="max_chapters" type="number" min="0" max="999" value="' . (int) ( $e['max_chapters'] ?? 0 ) . '"><small>0 = כל הספר. למשל 3 = רק שלושת הפרקים הראשונים</small></label>';
		echo '<label>בתוקף עד <input name="expires_at" type="date" value="' . esc_attr( $e['expires_at'] ? substr( $e['expires_at'], 0, 10 ) : '' ) . '"><small>ריק = ללא תפוגה</small></label>';
		echo '<label class="wide">הערה פנימית <input name="note" value="' . esc_attr( $e['note'] ) . '" placeholder="למשל: סופר, ביקש לקרוא את חלק ב׳"></label>';
		echo '<div class="wide"><button class="button button-primary button-hero">' . ( $edit ? 'שמירה' : 'יצירת קישור' ) . '</button>';
		if ( $edit ) {
			echo ' <a class="button" href="' . esc_url( admin_url( 'admin.php?page=rpb' ) ) . '">ביטול</a>';
		}
		echo '</div></form></div>';

		// list
		echo '<h2>' . count( $rows ) . ' קוראים</h2><div class="rpb-table-wrap"><table class="widefat striped rpb-table"><thead><tr><th>קורא</th><th>קישור</th><th>מצב</th><th>מכשירים</th><th>כניסות</th><th>התקדמות</th><th>נראה לאחרונה</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="8">עוד אין קוראים. צור את הקישור הראשון למעלה.</td></tr>';
		}
		foreach ( $rows as $r ) {
			$prob = RPB_Access::invite_problem( $r );
			$stat = '' === $prob ? '<span class="pill ok">פעיל</span>' : ( 'revoked' === $prob ? '<span class="pill off">מבוטל</span>' : '<span class="pill warn">פג תוקף</span>' );
			$prog = json_decode( (string) $r['progress'], true );
			$pg   = array();
			foreach ( array( 'he', 'en' ) as $l ) {
				if ( ! empty( $prog[ $l ] ) ) {
					$pg[] = '<span class="bar"><i style="width:' . (float) $prog[ $l ]['max'] . '%"></i></span> ' . esc_html( round( (float) $prog[ $l ]['max'] ) . '%' . ( 'en' === $l ? ' EN' : '' ) ) . '<br><small>' . esc_html( $prog[ $l ]['title'] ) . '</small>';
				}
			}
			$dev = RPB_Access::devices( $r );
			echo '<tr' . ( $prob ? ' class="dim"' : '' ) . '><td><b>' . esc_html( $r['name'] ? $r['name'] : '(ללא שם)' ) . '</b><br><small>' . esc_html( self::lang_label( $r['lang'] ) ) . ( (int) $r['max_chapters'] ? ' · ' . (int) $r['max_chapters'] . ' פרקים ראשונים' : '' ) . ( $r['note'] ? ' · ' . esc_html( $r['note'] ) : '' ) . '</small></td>';
			echo '<td>';
			self::copy_field( RPB_Settings::invite_url( $r['token'] ) );
			echo '</td><td>' . $stat . ( $r['expires_at'] ? '<br><small>עד ' . esc_html( wp_date( 'j.n.y', strtotime( $r['expires_at'] . ' UTC' ) ) ) . '</small>' : '' ) . '</td>'; // phpcs:ignore
			echo '<td>' . count( $dev ) . ' / ' . ( (int) $r['max_devices'] ? (int) $r['max_devices'] : '∞' ) . '</td><td>' . (int) $r['opens'] . '<br><small>' . (int) $r['reads_count'] . ' פרקים</small></td>';
			echo '<td class="prog">' . ( $pg ? implode( '<br>', $pg ) : '—' ) . '</td><td>' . self::dt( $r['last_seen'] ) . '</td><td class="acts">'; // phpcs:ignore
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=rpb&edit=' . (int) $r['id'] ) ) . '">עריכה</a> · ';
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=rpb&new=' . (int) $r['id'] ) ) . '">שליחה</a> · ';
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=rpb-log&invite=' . (int) $r['id'] ) ) . '">יומן</a><br>';
			if ( (int) $r['revoked'] ) {
				self::btn_post( 'invite_restore', $r['id'], 'החזרה' );
			} else {
				self::btn_post( 'invite_revoke', $r['id'], 'ביטול קישור', 'button-link danger', 'לבטל את הקישור? הקורא לא יוכל להיכנס יותר.' );
			}
			echo ' · ';
			self::btn_post( 'invite_reset', $r['id'], 'איפוס מכשירים', 'button-link', 'לאפס את המכשירים? הקורא יצטרך לפתוח שוב את הקישור.' );
			echo ' · ';
			self::btn_post( 'invite_rotate', $r['id'], 'קישור חדש', 'button-link', 'ליצור קישור חדש במקום הישן? הקישור הישן יפסיק לעבוד.' );
			echo ' · ';
			self::btn_post( 'invite_delete', $r['id'], 'מחיקה', 'button-link danger', 'למחוק את הקורא וכל ההיסטוריה שלו?' );
			echo '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	public static function page_update() {
		$key   = RPB_Settings::update_key();
		$last  = get_option( 'rpb_last_import' );
		$pull  = get_option( 'rpb_pull_state' );
		$log   = get_option( 'rpb_changelog' );
		self::header( 'עדכון הספר', 'הקוראים מקבלים את הגרסה החדשה מיד, בכניסה הבאה שלהם, וממשיכים בדיוק מאותו מקום. מי שהגרסה החדשה חדשה לו יראה הודעה קטנה "הספר עודכן".' );
		echo '<div class="rpb-cols">';
		foreach ( array( 'he' => 'עברית', 'en' => 'אנגלית' ) as $l => $name ) {
			$m = RPB_DB::meta( $l );
			echo '<div class="rpb-card stat"><h2>' . esc_html( $name ) . '</h2>';
			if ( $m ) {
				echo '<p class="big">' . esc_html( $m['title'] ) . '</p><p>' . (int) $m['chapters'] . ' חלקים · ' . esc_html( number_format_i18n( $m['words'] ) ) . ' מילים</p><p><small>גרסה ' . esc_html( substr( $m['version'], 0, 8 ) ) . ' · נבנתה ' . esc_html( $m['generated_ts'] ? wp_date( 'j.n.y H:i', $m['generated_ts'] ) : '—' ) . ' · נטענה ' . esc_html( wp_date( 'j.n.y H:i', $m['imported'] ) ) . '</small></p>';
			} else {
				echo '<p>עוד לא הועלה.</p>';
			}
			echo '</div>';
		}
		echo '</div>';

		echo '<div class="rpb-card"><h2>1. העלאה ידנית</h2><p>מעלים את קובץ החבילה שקיבלת (<code>.rpb</code>, או <code>.zip</code> / <code>.json</code>). אפשר לצרף משפט קצר על מה השתנה, והקוראים יראו אותו בהודעת העדכון. בלי משפט כזה העדכון שקט: הספר מתעדכן והקוראים לא מקבלים שום הודעה.</p>';
		self::form_open( 'upload', 'enctype="multipart/form-data" class="rpb-grid"' );
		echo '<label class="wide">קובץ החבילה <input type="file" name="pkg" required accept=".rpb,.zip,.json,.gz"></label>';
		echo '<label>מה חדש (עברית, לא חובה) <input name="note_he" placeholder="למשל: עריכה של פרקים 10–17"></label><label>What\'s new (English, optional) <input name="note_en" dir="ltr"></label>';
		echo '<label class="wide check"><input type="checkbox" name="force" value="1"> לטעון גם אם החבילה ישנה יותר מהגרסה שכבר באתר</label>';
		echo '<div class="wide"><button class="button button-primary button-hero">העלאה ועדכון מיידי</button></div></form></div>';

		echo '<div class="rpb-card"><h2>2. עדכון אוטומטי בכל בנייה</h2><p>כשבונים את הספר מחדש, סקריפט הבנייה יכול לשלוח את הגרסה ישר לאתר, בלי שתצטרך לעשות כלום. לשם כך הוא צריך את שני הפרטים האלה. שמור אותם בסוד: מי שמחזיק במפתח יכול לעדכן את הספר.</p>';
		echo '<p><b>כתובת האתר:</b> ';
		self::copy_field( home_url( '/' ) );
		echo '</p><p><b>מפתח העדכון:</b> ';
		self::copy_field( $key );
		echo '</p>';
		self::form_open( 'rotate_key', 'class="inline" data-confirm="ליצור מפתח חדש? המפתח הישן יפסיק לעבוד."' );
		echo '<button class="button">יצירת מפתח חדש</button></form>';
		echo '<details><summary>איך זה עובד (טכני)</summary><p>הבנייה מצפינה את הספר עם המפתח (AES-256-GCM) ושולחת אותו אל <code dir="ltr">' . esc_html( admin_url( 'admin-post.php?action=rpb_push' ) ) . '</code>. האתר מקבל רק חבילה שהוצפנה עם המפתח שלו. אפשר גם להעלות את קובץ ה־<code>.rpb</code> לכל מקום ציבורי (Google Drive, Dropbox) ולהגדיר למטה את הכתובת שלו. האתר יבדוק אותה כל 10 דקות, ומי שאין לו את המפתח לא יוכל לקרוא את הקובץ.</p></details></div>';

		echo '<div class="rpb-card"><h2>3. בדיקה אוטומטית של כתובת (לא חובה)</h2>';
		self::form_open( 'pull_save', 'class="rpb-grid"' );
		echo '<label class="wide">כתובת קובץ ה־.rpb <input name="pull_url" dir="ltr" value="' . esc_attr( RPB_Settings::get( 'pull_url' ) ) . '" placeholder="https://..."></label>';
		echo '<div class="wide"><button class="button">שמירה</button> <button class="button" name="check" value="1">שמירה ובדיקה עכשיו</button>';
		if ( is_array( $pull ) && ! empty( $pull['checked'] ) ) {
			echo ' <small>נבדק לאחרונה ' . esc_html( wp_date( 'j.n.y H:i', $pull['checked'] ) ) . ( ! empty( $pull['error'] ) ? ' · <span class="danger">' . esc_html( $pull['error'] ) . '</span>' : ' · תקין' ) . '</small>';
		}
		echo '</div></form></div>';

		if ( is_array( $log ) && $log ) {
			$src = array( 'upload' => 'העלאה', 'push' => 'אוטומטי מהבנייה', 'pull' => 'בדיקה אוטומטית' );
			echo '<div class="rpb-card"><h2>היסטוריית גרסאות</h2><table class="widefat striped"><thead><tr><th>מתי</th><th>שפה</th><th>גרסה</th><th>מילים</th><th>איך</th><th>מה חדש</th></tr></thead><tbody>';
			foreach ( array_slice( $log, 0, 25 ) as $c ) {
				echo '<tr><td>' . esc_html( wp_date( 'j.n.y H:i', $c['at'] ) ) . '</td><td>' . esc_html( self::lang_label( $c['lang'] ) ) . '</td><td><code>' . esc_html( substr( $c['version'], 0, 8 ) ) . '</code></td><td>' . esc_html( number_format_i18n( $c['words'] ) ) . '</td><td>' . esc_html( $src[ $c['source'] ] ?? $c['source'] ) . '</td><td>' . esc_html( $c['note'] ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
	}

	public static function page_requests() {
		global $wpdb;
		$t    = RPB_DB::t( 'requests' );
		$kind = ( isset( $_GET['kind'] ) && 'access' === $_GET['kind'] ) ? 'access' : 'launch'; // phpcs:ignore
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE kind = %s ORDER BY id DESC LIMIT 2000", $kind ), ARRAY_A ); // phpcs:ignore
		$nl   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE kind = 'launch'" ); // phpcs:ignore
		$na   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE kind = 'access'" ); // phpcs:ignore
		self::header( 'נרשמים ובקשות', 'מעמוד הנחיתה. לפי חוק הספאם, הודעה פרסומית (כמו הצעת מחיר השקה) שולחים רק למי שמסומן ✓ בעמודת "דיוור".' );
		$base = admin_url( 'admin.php?page=rpb-requests' );
		echo '<h2 class="nav-tab-wrapper"><a class="nav-tab' . ( 'launch' === $kind ? ' nav-tab-active' : '' ) . '" href="' . esc_url( $base ) . '">נרשמים למחיר השקה (' . $nl . ')</a><a class="nav-tab' . ( 'access' === $kind ? ' nav-tab-active' : '' ) . '" href="' . esc_url( $base . '&kind=access' ) . '">בקשות לקריאה מוקדמת (' . $na . ')</a></h2>';
		self::form_open( 'export_requests', 'class="inline"' );
		echo '<input type="hidden" name="kind" value="' . esc_attr( $kind ) . '"><button class="button">הורדה לאקסל (CSV)</button></form>';
		echo '<div class="rpb-table-wrap"><table class="widefat striped rpb-table"><thead><tr><th>מתי</th><th>שם</th><th>מייל</th><th>טלפון</th><th>שפה</th>' . ( 'access' === $kind ? '<th>הודעה</th>' : '<th>דיוור</th>' ) . '<th>מצב</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="8">עוד אין.</td></tr>';
		}
		foreach ( $rows as $r ) {
			echo '<tr' . ( 'new' === $r['status'] ? ' class="new"' : '' ) . '><td>' . self::dt( $r['at'] ) . '</td><td><b>' . esc_html( $r['name'] ) . '</b></td><td dir="ltr">' . esc_html( $r['email'] ) . '</td><td dir="ltr">' . esc_html( $r['phone'] ) . '</td><td>' . esc_html( self::lang_label( $r['lang'] ) ) . '</td>'; // phpcs:ignore
			echo 'access' === $kind ? '<td class="msg">' . esc_html( $r['message'] ) . '</td>' : '<td>' . ( $r['consent'] ? '✓' : '—' ) . '</td>';
			echo '<td>' . ( 'new' === $r['status'] ? '<span class="pill warn">חדש</span>' : ( 'invited' === $r['status'] ? '<span class="pill ok">קיבל קישור</span>' : ( 'done' === $r['status'] ? '<span class="pill">טופל</span>' : '' ) ) ) . '</td><td class="acts">';
			if ( 'access' === $kind && 'invited' !== $r['status'] ) {
				self::btn_post( 'request_invite', $r['id'], 'אישור ויצירת קישור', 'button button-primary' );
				echo ' ';
			}
			if ( 'done' !== $r['status'] && 'invited' !== $r['status'] ) {
				self::btn_post( 'request_done', $r['id'], 'סימון כטופל' );
				echo ' · ';
			}
			self::btn_post( 'request_delete', $r['id'], 'מחיקה', 'button-link danger', 'למחוק?' );
			echo '</td></tr>';
		}
		echo '</tbody></table></div></div>';
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET status = 'seen' WHERE status = 'new' AND kind = %s", 'launch' === $kind ? 'launch' : 'none' ) ); // phpcs:ignore
	}

	public static function page_notes() {
		global $wpdb;
		$n    = RPB_DB::t( 'notes' );
		$i    = RPB_DB::t( 'invites' );
		$rows = $wpdb->get_results( "SELECT n.*, i.name FROM $n n LEFT JOIN $i i ON i.id = n.invite_id ORDER BY n.done ASC, n.id DESC LIMIT 1000", ARRAY_A ); // phpcs:ignore
		self::header( 'הערות קוראים', 'מה שהקוראים כתבו לך מתוך הספר, עם הפרק והעמוד שבו היו.' );
		self::form_open( 'export_notes', 'class="inline"' );
		echo '<button class="button">הורדה לאקסל (CSV)</button></form>';
		echo '<div class="rpb-notes">';
		if ( ! $rows ) {
			echo '<p>עוד אין הערות.</p>';
		}
		foreach ( $rows as $r ) {
			echo '<div class="rpb-card note' . ( $r['done'] ? ' dim' : '' ) . '"><div class="meta"><b>' . esc_html( $r['name'] ? $r['name'] : ( $r['invite_id'] ? 'קורא #' . $r['invite_id'] : 'אתה (תצוגה מקדימה)' ) ) . '</b> · ' . esc_html( $r['chapter'] ) . ' · עמוד ' . (int) $r['page'] . ' · ' . esc_html( self::lang_label( $r['lang'] ) ) . ' · ' . self::dt( $r['at'] ) . '</div><p>' . nl2br( esc_html( $r['body'] ) ) . '</p><div class="acts">'; // phpcs:ignore
			self::btn_post( 'note_done', $r['id'], $r['done'] ? 'החזרה לפתוחות' : 'סימון כטופל' );
			echo ' · ';
			self::btn_post( 'note_delete', $r['id'], 'מחיקה', 'button-link danger', 'למחוק את ההערה?' );
			echo '</div></div>';
		}
		echo '</div></div>';
	}

	public static function page_notify() {
		global $wpdb;
		$t    = RPB_DB::t( 'invites' );
		$rows = $wpdb->get_results( "SELECT * FROM $t WHERE revoked = 0 ORDER BY name ASC", ARRAY_A ); // phpcs:ignore
		$rows = array_filter( $rows, function ( $r ) { return '' === RPB_Access::invite_problem( $r ); } );
		$withmail = count( array_filter( $rows, function ( $r ) { return is_email( $r['email'] ); } ) );
		$draft = get_option( 'rpb_notify_draft' );
		$d     = is_array( $draft ) ? $draft : array(
			'sub_he'  => 'חצי סנטימטר: יש גרסה חדשה',
			'sub_en'  => 'Half an Inch: a new version is here',
			'body_he' => RPB_Notify::default_message( 'he' ),
			'body_en' => RPB_Notify::default_message( 'en' ),
		);
		self::header( 'הודעה לכל הקוראים', 'הספר עצמו כבר מעודכן אצל כולם. כאן שולחים הודעה שיש מה לקרוא. <code>{name}</code> יוחלף בשם הקורא, ו־<code>{link}</code> בקישור האישי שלו.' );
		self::form_open( 'notify_send', 'class="rpb-grid" data-confirm="לשלוח את המייל לכל הקוראים שיש להם כתובת מייל?"' );
		echo '<label>נושא (עברית) <input name="sub_he" value="' . esc_attr( $d['sub_he'] ) . '"></label><label>Subject (English) <input name="sub_en" dir="ltr" value="' . esc_attr( $d['sub_en'] ) . '"></label>';
		echo '<label>הודעה (עברית) <textarea name="body_he" rows="9">' . esc_textarea( $d['body_he'] ) . '</textarea></label><label>Message (English) <textarea name="body_en" dir="ltr" rows="9">' . esc_textarea( $d['body_en'] ) . '</textarea></label>';
		echo '<div class="wide"><button class="button" name="save_only" value="1">שמירת הנוסח</button> <button class="button button-primary button-hero">שליחה במייל ל־' . (int) $withmail . ' קוראים</button><p><small>המיילים נשלחים מהאתר. אם הם לא מגיעים, מתקינים תוסף SMTP (למשל WP Mail SMTP) שמחבר את האתר לתיבת המייל שלך.</small></p></div></form>';
		echo '<div class="rpb-card"><h2>שליחה בוואטסאפ</h2><p>כל כפתור פותח וואטסאפ עם ההודעה האישית והקישור של אותו קורא. נשאר רק ללחוץ "שלח".</p><div class="rpb-wa-list">';
		foreach ( $rows as $r ) {
			$en  = 'en' === $r['lang'];
			$msg = RPB_Notify::fill( $en ? $d['body_en'] : $d['body_he'], $r );
			echo '<a class="button rpb-wa" target="_blank" rel="noopener" href="' . esc_url( RPB_Notify::whatsapp_url( $r, $msg ) ) . '">' . esc_html( $r['name'] ? $r['name'] : '#' . $r['id'] ) . ( $r['phone'] ? '' : ' (בלי טלפון)' ) . '</a> ';
		}
		if ( ! $rows ) {
			echo 'אין קוראים פעילים.';
		}
		echo '</div></div></div>';
	}

	public static function page_log() {
		global $wpdb;
		$l   = RPB_DB::t( 'log' );
		$i   = RPB_DB::t( 'invites' );
		$inv = isset( $_GET['invite'] ) ? (int) $_GET['invite'] : 0; // phpcs:ignore
		$sql = "SELECT g.*, i.name FROM $l g LEFT JOIN $i i ON i.id = g.invite_id" . ( $inv ? $wpdb->prepare( ' WHERE g.invite_id = %d', $inv ) : '' ) . ' ORDER BY g.id DESC LIMIT 500';
		$rows = $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		$ev   = array( 'open' => 'פתח/ה את הקישור', 'chapter' => 'קרא/ה פרק', 'denied' => 'ניסיון עם קישור לא פעיל', 'limit' => 'נחסם: יותר מדי מכשירים', 'note' => 'שלח/ה הערה', 'mailed' => 'נשלח מייל עדכון' );
		self::header( 'יומן כניסות', $inv ? 'מסונן לקורא אחד. <a href="' . esc_url( admin_url( 'admin.php?page=rpb-log' ) ) . '">להציג את כולם</a>' : '500 הפעולות האחרונות. נשמר עד חצי שנה.' );
		echo '<div class="rpb-table-wrap"><table class="widefat striped rpb-table"><thead><tr><th>מתי</th><th>קורא</th><th>מה</th><th>פרטים</th><th>IP</th><th>מכשיר</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="6">אין עדיין רשומות.</td></tr>';
		}
		foreach ( $rows as $r ) {
			echo '<tr' . ( in_array( $r['event'], array( 'denied', 'limit' ), true ) ? ' class="warnrow"' : '' ) . '><td>' . self::dt( $r['at'] ) . '</td><td><a href="' . esc_url( admin_url( 'admin.php?page=rpb-log&invite=' . (int) $r['invite_id'] ) ) . '">' . esc_html( $r['name'] ? $r['name'] : '#' . $r['invite_id'] ) . '</a></td><td>' . esc_html( $ev[ $r['event'] ] ?? $r['event'] ) . '</td><td>' . esc_html( $r['detail'] ) . ( $r['lang'] ? ' <small>' . esc_html( strtoupper( $r['lang'] ) ) . '</small>' : '' ) . '</td><td dir="ltr">' . esc_html( $r['ip'] ) . '</td><td class="ua"><small>' . esc_html( self::short_ua( $r['ua'] ) ) . '</small></td></tr>'; // phpcs:ignore
		}
		echo '</tbody></table></div></div>';
	}

	private static function short_ua( $ua ) {
		$os = preg_match( '/iPhone|iPad/', $ua ) ? 'iPhone/iPad' : ( false !== stripos( $ua, 'Android' ) ? 'Android' : ( false !== stripos( $ua, 'Mac OS' ) ? 'Mac' : ( false !== stripos( $ua, 'Windows' ) ? 'Windows' : '' ) ) );
		$br = preg_match( '/Edg\//', $ua ) ? 'Edge' : ( preg_match( '/Chrome\//', $ua ) ? 'Chrome' : ( preg_match( '/Firefox\//', $ua ) ? 'Firefox' : ( preg_match( '/Safari\//', $ua ) ? 'Safari' : '' ) ) );
		return trim( $os . ' ' . $br ) ? trim( $os . ' · ' . $br, ' ·' ) : mb_substr( $ua, 0, 40 );
	}

	public static function page_settings() {
		$s = RPB_Settings::all();
		self::header( 'הגדרות ועמוד נחיתה' );
		self::form_open( 'settings', 'class="rpb-grid"' );
		$cb = function ( $k, $label, $help = '' ) use ( $s ) {
			echo '<label class="wide check"><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $s[ $k ] ), true, false ) . '> ' . esc_html( $label ) . ( $help ? '<small>' . esc_html( $help ) . '</small>' : '' ) . '</label>';
		};
		echo '<h2 class="wide">כתובת</h2>';
		echo '<label>כתובת עמוד הספר <span class="slug" dir="ltr">' . esc_html( home_url( '/' ) ) . '<input name="slug" value="' . esc_attr( $s['slug'] ) . '" dir="ltr">/</span><small>שינוי הכתובת משנה גם את כל הקישורים האישיים</small></label>';
		$cb( 'landing_index', 'לאפשר לגוגל להציג את עמוד הנחיתה בתוצאות חיפוש', 'רק עמוד הנחיתה (כריכה ותקציר). הספר עצמו לעולם לא נגיש למנועי חיפוש.' );
		$cb( 'landing_requests', 'להציג בעמוד הנחיתה טופס "בקשת גישה לקריאה מוקדמת"' );
		echo '<h2 class="wide">הגנה</h2>';
		$cb( 'block_ai_sitewide', 'לחסום בוטים של בינה מלאכותית בכל האתר', 'GPTBot, ClaudeBot, Google-Extended, CCBot, Perplexity ועוד: חסימה ב־robots.txt, ב־ai.txt ובשרת עצמו' );
		$cb( 'protect_copy', 'למנוע סימון, העתקה, הדפסה ולחיצה ימנית בקורא' );
		$cb( 'watermark', 'להציג בעדינות את שם הקורא על כל עמוד', 'צילום מסך יישא את שם הקורא' );
		$cb( 'leak_trace', 'טביעת אצבע נסתרת בטקסט', 'סימן בלתי נראה שמזהה מאיזה קורא הועתק הטקסט. אפשר לבדוק טקסט חשוד למטה.' );
		$cb( 'notify_requests', 'לשלוח לי מייל על נרשם חדש, בקשת גישה או הערת קורא' );
		echo '<label>מייל ליצירת קשר (במדיניות הפרטיות) <input type="email" name="contact_email" dir="ltr" value="' . esc_attr( $s['contact_email'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"></label>';
		echo '<label>מספר מכשירים לכל קישור (ברירת מחדל) <input type="number" name="max_devices" min="0" max="50" value="' . (int) $s['max_devices'] . '"></label>';
		echo '<label>כמה ימים מכשיר נשאר מחובר <input type="number" name="session_days" min="1" max="730" value="' . (int) $s['session_days'] . '"></label>';
		echo '<h2 class="wide">טקסטים בעמוד הנחיתה</h2>';
		$pairs = array(
			'eyebrow'  => array( 'שורה מעל הכותרת', 'Line above the title', 1 ),
			'tagline'  => array( 'משפט פתיחה', 'Tagline', 1 ),
			'blurb'    => array( 'התקציר (פסקה ריקה בין פסקאות)', 'Blurb (blank line between paragraphs)', 10 ),
			'launch'   => array( 'טקסט ההרשמה למחיר השקה', 'Launch sign-up text', 2 ),
			'status'   => array( 'מצב הספר (קריאה בהזמנה)', 'Book status (invitation only)', 2 ),
			'quotes'   => array( 'ציטוטים מקוראים: שורה לכל ציטוט, בפורמט ציטוט | שם. רק ציטוטים אמיתיים, באישור הכותב.', 'Reader quotes: one per line, quote | name', 4 ),
			'comps'    => array( 'למי זה מתאים', 'Comparable titles line', 1 ),
			'adult'    => array( 'הערת תוכן (למבוגרים)', 'Content note', 1 ),
			'faq'      => array( 'שאלות נפוצות: שורה לכל שאלה, בפורמט שאלה | תשובה', 'FAQ: one per line, question | answer', 5 ),
			'author'   => array( 'שם הסופר', 'Author name', 1 ),
		);
		foreach ( $pairs as $k => $p ) {
			foreach ( array( 'he', 'en' ) as $i => $l ) {
				$v = $s[ $k . '_' . $l ];
				echo '<label>' . esc_html( $p[ $i ] ) . ( $p[2] > 1 ? '<textarea name="' . esc_attr( $k . '_' . $l ) . '" rows="' . (int) $p[2] . '"' . ( 'en' === $l ? ' dir="ltr"' : '' ) . '>' . esc_textarea( $v ) . '</textarea>' : '<input name="' . esc_attr( $k . '_' . $l ) . '" value="' . esc_attr( $v ) . '"' . ( 'en' === $l ? ' dir="ltr"' : '' ) . '>' ) . '</label>';
			}
		}
		echo '<div class="wide"><button class="button button-primary button-hero">שמירת ההגדרות</button> <button class="button" name="reset_texts" value="1" data-confirm="להחזיר את כל הטקסטים לנוסח המקורי?">החזרת הטקסטים לנוסח המקורי</button></div></form>';

		echo '<div class="rpb-card"><h2>איתור דליפה</h2><p>מצאת קטע מהספר במקום שלא היה צריך להיות? הדבק אותו כאן כמו שהוא, ונבדוק אם יש בו טביעת אצבע של קורא.</p>';
		self::form_open( 'trace' );
		echo '<textarea name="text" rows="5" style="width:100%"></textarea><p><button class="button">בדיקה</button></p></form></div>';
		echo '<div class="rpb-card"><h2>מה ההגנה עושה, ומה לא</h2><ul class="ul"><li>הטקסט של הספר נשמר רק במסד הנתונים, ולא כעמוד, פוסט או קובץ באתר. לכן אין לו כתובת שמנוע חיפוש יכול למצוא.</li><li>כל פרק נשלח רק לקורא עם קישור תקף, אחד בכל פעם, עם הוראות "אל תאנדקס, אל תשמור, לא ל־AI".</li><li>robots.txt ו־ai.txt חוסמים את הבוטים המוכרים של OpenAI, Anthropic, Google AI, Common Crawl, Perplexity, Meta ועוד, והשרת מחזיר להם שגיאה.</li><li><b>בכנות:</b> אדם שקיבל קישור ומחליט להעתיק (צילום מסך, הקלדה) יכול לעשות את זה. סימן המים, טביעת האצבע והיומן נועדו להרתיע, ולגלות מי עשה את זה אם זה קורה.</li></ul></div>';
		echo '</div>';
	}

	/* ---------- actions ---------- */

	public static function handle() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'אין הרשאה' );
		}
		check_admin_referer( 'rpb_admin' );
		global $wpdb;
		$do = sanitize_key( $_POST['do'] ?? '' );
		$id = (int) ( $_POST['id'] ?? 0 );
		$p  = wp_unslash( $_POST );

		switch ( $do ) {
			case 'invite_create':
				$nid = RPB_Access::create_invite( $p );
				self::back( 'rpb', array( 'new' => $nid ) );
				break;
			case 'invite_update':
				RPB_Access::update_invite(
					$id,
					array(
						'name'        => mb_substr( sanitize_text_field( $p['name'] ?? '' ), 0, 190 ),
						'email'       => sanitize_email( $p['email'] ?? '' ),
						'phone'       => preg_replace( '/[^0-9+]/', '', (string) ( $p['phone'] ?? '' ) ),
						'lang'        => in_array( $p['lang'] ?? 'both', array( 'he', 'en', 'both' ), true ) ? $p['lang'] : 'both',
						'note'        => sanitize_textarea_field( $p['note'] ?? '' ),
						'max_devices' => max( 0, min( 50, (int) ( $p['max_devices'] ?? 3 ) ) ),
						'max_chapters' => max( 0, min( 999, (int) ( $p['max_chapters'] ?? 0 ) ) ),
						'expires_at'  => ! empty( $p['expires_at'] ) ? gmdate( 'Y-m-d 23:59:59', strtotime( $p['expires_at'] ) ) : null,
					)
				);
				self::flash( 'success', 'נשמר.' );
				self::back( 'rpb' );
				break;
			case 'invite_revoke':
			case 'invite_restore':
				RPB_Access::update_invite( $id, array( 'revoked' => 'invite_revoke' === $do ? 1 : 0 ) );
				self::flash( 'success', 'invite_revoke' === $do ? 'הקישור בוטל. הקורא לא יוכל להיכנס יותר.' : 'הקישור פעיל שוב.' );
				self::back( 'rpb' );
				break;
			case 'invite_reset':
				RPB_Access::update_invite( $id, array( 'devices' => '[]' ) );
				self::flash( 'success', 'המכשירים אופסו. הקורא יפתח שוב את הקישור שלו.' );
				self::back( 'rpb' );
				break;
			case 'invite_rotate':
				RPB_Access::update_invite( $id, array( 'token' => RPB_Settings::random( 18 ), 'devices' => '[]' ) );
				self::flash( 'success', 'נוצר קישור חדש. הישן כבר לא עובד.' );
				self::back( 'rpb', array( 'new' => $id ) );
				break;
			case 'invite_delete':
				$wpdb->delete( RPB_DB::t( 'invites' ), array( 'id' => $id ) );
				$wpdb->delete( RPB_DB::t( 'log' ), array( 'invite_id' => $id ) );
				self::flash( 'success', 'נמחק.' );
				self::back( 'rpb' );
				break;

			case 'upload':
				if ( empty( $_FILES['pkg']['tmp_name'] ) || ! is_uploaded_file( $_FILES['pkg']['tmp_name'] ) ) { // phpcs:ignore
					self::flash( 'error', 'לא התקבל קובץ. ייתכן שהוא גדול מהמותר בשרת.' );
					self::back( 'rpb-update' );
				}
				$bytes = file_get_contents( $_FILES['pkg']['tmp_name'] ); // phpcs:ignore
				$pkg   = RPB_Import::decode( (string) $bytes );
				if ( is_wp_error( $pkg ) ) {
					self::flash( 'error', esc_html( $pkg->get_error_message() ) );
					self::back( 'rpb-update' );
				}
				foreach ( array( 'he', 'en' ) as $l ) {
					$n = trim( sanitize_text_field( $p[ 'note_' . $l ] ?? '' ) );
					if ( $n ) {
						if ( ! isset( $pkg['note'] ) || ! is_array( $pkg['note'] ) ) {
							$pkg['note'] = array();
						}
						$pkg['note'][ $l ] = $n;
					}
				}
				$res = RPB_Import::import( $pkg, 'upload', ! empty( $p['force'] ) );
				self::flash_import( $res );
				self::back( 'rpb-update' );
				break;
			case 'rotate_key':
				update_option( 'rpb_update_key', RPB_Settings::random( 32 ), false );
				self::flash( 'warning', 'נוצר מפתח עדכון חדש. צריך לעדכן אותו גם בסקריפט הבנייה.' );
				self::back( 'rpb-update' );
				break;
			case 'pull_save':
				RPB_Settings::save( array( 'pull_url' => esc_url_raw( trim( $p['pull_url'] ?? '' ) ) ) );
				if ( ! empty( $p['check'] ) ) {
					self::flash_import( RPB_Import::pull( true ) );
				} else {
					self::flash( 'success', 'נשמר.' );
				}
				self::back( 'rpb-update' );
				break;

			case 'request_invite':
				$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . RPB_DB::t( 'requests' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
				if ( $r ) {
					$nid = RPB_Access::create_invite( array( 'name' => $r['name'], 'email' => $r['email'], 'phone' => $r['phone'], 'lang' => 'both', 'note' => 'מבקשת גישה בעמוד הנחיתה' ) );
					$wpdb->update( RPB_DB::t( 'requests' ), array( 'status' => 'invited' ), array( 'id' => $id ) );
					self::back( 'rpb', array( 'new' => $nid ) );
				}
				self::back( 'rpb-requests', array( 'kind' => 'access' ) );
				break;
			case 'request_done':
			case 'request_delete':
				$r = $wpdb->get_row( $wpdb->prepare( 'SELECT kind FROM ' . RPB_DB::t( 'requests' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
				if ( 'request_done' === $do ) {
					$wpdb->update( RPB_DB::t( 'requests' ), array( 'status' => 'done' ), array( 'id' => $id ) );
				} else {
					$wpdb->delete( RPB_DB::t( 'requests' ), array( 'id' => $id ) );
				}
				self::back( 'rpb-requests', ( $r && 'access' === $r['kind'] ) ? array( 'kind' => 'access' ) : array() );
				break;
			case 'export_requests':
				$kind = ( 'access' === ( $p['kind'] ?? '' ) ) ? 'access' : 'launch';
				$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT at, name, email, phone, lang, consent, message, status FROM ' . RPB_DB::t( 'requests' ) . ' WHERE kind = %s ORDER BY id ASC', $kind ), ARRAY_A ); // phpcs:ignore
				self::csv( 'launch' === $kind ? 'launch-signups' : 'early-reader-requests', array( 'תאריך', 'שם', 'מייל', 'טלפון', 'שפה', 'הסכמה לדיוור', 'הודעה', 'מצב' ), $rows );
				break;

			case 'note_done':
				$cur = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT done FROM ' . RPB_DB::t( 'notes' ) . ' WHERE id = %d', $id ) ); // phpcs:ignore
				$wpdb->update( RPB_DB::t( 'notes' ), array( 'done' => $cur ? 0 : 1 ), array( 'id' => $id ) );
				self::back( 'rpb-notes' );
				break;
			case 'note_delete':
				$wpdb->delete( RPB_DB::t( 'notes' ), array( 'id' => $id ) );
				self::back( 'rpb-notes' );
				break;
			case 'export_notes':
				$rows = $wpdb->get_results( 'SELECT n.at, i.name, n.lang, n.chapter, n.page, n.body FROM ' . RPB_DB::t( 'notes' ) . ' n LEFT JOIN ' . RPB_DB::t( 'invites' ) . ' i ON i.id = n.invite_id ORDER BY n.id ASC', ARRAY_A ); // phpcs:ignore
				self::csv( 'reader-notes', array( 'תאריך', 'קורא', 'שפה', 'פרק', 'עמוד', 'הערה' ), $rows );
				break;

			case 'notify_send':
				$d = array(
					'sub_he'  => sanitize_text_field( $p['sub_he'] ?? '' ),
					'sub_en'  => sanitize_text_field( $p['sub_en'] ?? '' ),
					'body_he' => sanitize_textarea_field( $p['body_he'] ?? '' ),
					'body_en' => sanitize_textarea_field( $p['body_en'] ?? '' ),
				);
				update_option( 'rpb_notify_draft', $d, false );
				if ( ! empty( $p['save_only'] ) ) {
					self::flash( 'success', 'הנוסח נשמר.' );
				} else {
					list( $sent, $fail, $skip ) = RPB_Notify::send_update( $d['sub_he'], $d['sub_en'], $d['body_he'], $d['body_en'] );
					self::flash( $fail ? 'warning' : 'success', "נשלחו $sent מיילים." . ( $fail ? " $fail נכשלו (כדאי להתקין תוסף SMTP)." : '' ) . ( $skip ? " $skip קוראים בלי מייל: אפשר לשלוח להם בוואטסאפ למטה." : '' ) );
				}
				self::back( 'rpb-notify' );
				break;

			case 'settings':
				if ( ! empty( $p['reset_texts'] ) ) {
					$def = RPB_Settings::defaults();
					$new = array();
					foreach ( array( 'eyebrow', 'tagline', 'blurb', 'launch', 'status', 'quotes', 'comps', 'adult', 'faq', 'author' ) as $k ) {
						$new[ $k . '_he' ] = $def[ $k . '_he' ];
						$new[ $k . '_en' ] = $def[ $k . '_en' ];
					}
					RPB_Settings::save( $new );
					self::flash( 'success', 'הטקסטים הוחזרו לנוסח המקורי.' );
					self::back( 'rpb-settings' );
				}
				$new = array(
					'slug'         => sanitize_title( $p['slug'] ?? 'book' ) ? sanitize_title( $p['slug'] ) : 'book',
					'max_devices'  => max( 0, min( 50, (int) ( $p['max_devices'] ?? 3 ) ) ),
					'session_days' => max( 1, min( 730, (int) ( $p['session_days'] ?? 180 ) ) ),
					'contact_email' => sanitize_email( $p['contact_email'] ?? '' ),
				);
				foreach ( array( 'landing_index', 'landing_requests', 'block_ai_sitewide', 'protect_copy', 'watermark', 'leak_trace', 'notify_requests' ) as $k ) {
					$new[ $k ] = empty( $p[ $k ] ) ? 0 : 1;
				}
				foreach ( array( 'eyebrow', 'tagline', 'blurb', 'launch', 'status', 'quotes', 'comps', 'adult', 'faq', 'author' ) as $k ) {
					foreach ( array( 'he', 'en' ) as $l ) {
						$new[ $k . '_' . $l ] = sanitize_textarea_field( $p[ $k . '_' . $l ] ?? '' );
					}
				}
				RPB_Settings::save( $new );
				self::flash( 'success', 'ההגדרות נשמרו.' );
				self::back( 'rpb-settings' );
				break;
			case 'trace':
				$ids = RPB_Access::trace( (string) ( $p['text'] ?? '' ) );
				if ( ! $ids ) {
					self::flash( 'warning', 'לא נמצאה טביעת אצבע. ייתכן שהטקסט הוקלד מחדש או צולם, או שהקטע קצר מדי (הסימן מופיע אחת לכמה פסקאות).' );
				} else {
					$out = array();
					foreach ( $ids as $iid => $n ) {
						$inv   = RPB_Access::invite( $iid );
						$out[] = '<b>' . esc_html( $inv ? ( $inv['name'] ? $inv['name'] : 'קורא #' . $iid ) : 'קורא #' . $iid . ' (נמחק)' ) . '</b> (' . (int) $n . ' סימנים)';
					}
					self::flash( 'error', 'הטקסט הגיע מהעותק של: ' . implode( ', ', $out ) );
				}
				self::back( 'rpb-settings' );
				break;
		}
		self::back( 'rpb' );
	}

	private static function flash_import( $res ) {
		if ( is_wp_error( $res ) ) {
			self::flash( 'error', esc_html( $res->get_error_message() ) );
			return;
		}
		$words = array( 'updated' => 'עודכן. הקוראים כבר רואים את הגרסה החדשה.', 'same' => 'זהה לגרסה שכבר באתר, לא השתנה כלום.', 'older' => 'החבילה ישנה מהגרסה שבאתר ולכן לא נטענה (אפשר לסמן "לטעון גם אם ישנה").' );
		$out   = array();
		foreach ( $res as $l => $r ) {
			if ( 'none' === $l ) {
				$out[] = 'אין גרסה חדשה בכתובת.';
				continue;
			}
			$out[] = '<b>' . esc_html( self::lang_label( $l ) ) . ':</b> ' . esc_html( $words[ $r ] ?? $r );
		}
		self::flash( in_array( 'updated', $res, true ) ? 'success' : 'info', implode( '<br>', $out ) );
	}

	private static function csv( $name, array $head, array $rows ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // Excel reads Hebrew correctly with a BOM
		fputcsv( $out, $head );
		foreach ( $rows as $r ) {
			if ( isset( $r['at'] ) ) {
				$r['at'] = wp_date( 'Y-m-d H:i', strtotime( $r['at'] . ' UTC' ) );
			}
			fputcsv(
				$out,
				array_map(
					function ( $v ) {
						$v = (string) $v;
						return preg_match( '/^[=+\-@]/', $v ) ? "'" . $v : $v; // no spreadsheet formulas
					},
					array_values( $r )
				)
			);
		}
		fclose( $out ); // phpcs:ignore
		exit;
	}
}
