<?php
/**
 * File: includes/class-rpb-import.php
 * Brings a new version of the book in. Three ways, all ending in import():
 *   1. Upload in wp-admin (.rpb encrypted package, or .zip / .json / .json.gz)
 *   2. Automatic push from the build script:  POST /wp-admin/admin-post.php?action=rpb_push  (encrypted package only)
 *   3. Automatic pull every hour from an address set in the settings (encrypted package only)
 * Readers get the new text on their very next page load. Their place is kept by chapter + position.
 *
 * Encrypted package (.rpb): "RPB1" + 12-byte nonce + AES-256-GCM ciphertext + 16-byte tag,
 * key = SHA-256("rpb-enc|" + site update key), plaintext = gzip(JSON). Only someone holding
 * the site's update key can create a package the site will accept, and nobody else can read it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Import {

	public static function init() {
		add_action( 'admin_post_nopriv_rpb_push', array( __CLASS__, 'push' ) );
		add_action( 'admin_post_rpb_push', array( __CLASS__, 'push' ) );
		add_action( 'rpb_pull', array( __CLASS__, 'pull' ) );
	}

	/* ---------- decoding ---------- */

	public static function decrypt( $bytes ) {
		$key = RPB_Settings::update_key();
		if ( ! $key || strlen( $bytes ) < 4 + 12 + 16 + 1 ) {
			return new WP_Error( 'rpb', 'חבילה פגומה.' );
		}
		$k     = hash( 'sha256', 'rpb-enc|' . $key, true );
		$nonce = substr( $bytes, 4, 12 );
		$tag   = substr( $bytes, -16 );
		$ct    = substr( $bytes, 16, -16 );
		$plain = openssl_decrypt( $ct, 'aes-256-gcm', $k, OPENSSL_RAW_DATA, $nonce, $tag, 'RPB1' );
		if ( false === $plain ) {
			return new WP_Error( 'rpb', 'החבילה לא נוצרה עם מפתח העדכון של האתר הזה (או שהיא פגומה).' );
		}
		return $plain;
	}

	/** Bytes of any supported package -> PHP array. $require_encrypted for push/pull. */
	public static function decode( $bytes, $require_encrypted = false ) {
		$enc = ( 0 === strncmp( $bytes, 'RPB1', 4 ) );
		if ( $require_encrypted && ! $enc ) {
			return new WP_Error( 'rpb', 'עדכון אוטומטי מקבל רק חבילה מוצפנת.' );
		}
		if ( $enc ) {
			$bytes = self::decrypt( $bytes );
			if ( is_wp_error( $bytes ) ) {
				return $bytes;
			}
		}
		if ( 0 === strncmp( $bytes, "PK\x03\x04", 4 ) ) {
			if ( ! class_exists( 'ZipArchive' ) ) {
				return new WP_Error( 'rpb', 'השרת לא תומך בקבצי ZIP. העלה את קובץ ה־.rpb או את book.json.' );
			}
			$tmp = tempnam( get_temp_dir(), 'rpb' );
			file_put_contents( $tmp, $bytes ); // phpcs:ignore
			$z     = new ZipArchive();
			$bytes = '';
			if ( true === $z->open( $tmp ) ) {
				for ( $i = 0; $i < $z->numFiles; $i++ ) {
					$n = $z->getNameIndex( $i );
					if ( preg_match( '/\.(json|rpb|gz)$/i', $n ) && false === strpos( $n, '__MACOSX' ) ) {
						$bytes = $z->getFromIndex( $i );
						break;
					}
				}
				$z->close();
			}
			@unlink( $tmp ); // phpcs:ignore
			if ( '' === $bytes ) {
				return new WP_Error( 'rpb', 'בתוך ה־ZIP לא נמצא קובץ ספר.' );
			}
			return self::decode( $bytes, false );
		}
		if ( 0 === strncmp( $bytes, "\x1f\x8b", 2 ) ) {
			$bytes = function_exists( 'gzdecode' ) ? gzdecode( $bytes ) : false;
			if ( false === $bytes ) {
				return new WP_Error( 'rpb', 'לא הצלחתי לפתוח את הקובץ הדחוס.' );
			}
		}
		$bytes = preg_replace( '/^\xEF\xBB\xBF/', '', $bytes );
		$pkg   = json_decode( $bytes, true );
		if ( ! is_array( $pkg ) || ( $pkg['format'] ?? '' ) !== 'rpb-1' || empty( $pkg['books'] ) ) {
			return new WP_Error( 'rpb', 'זה לא קובץ ספר תקין.' );
		}
		return $pkg;
	}

	/* ---------- importing ---------- */

	private static function allowed_html() {
		$c = array( 'class' => true, 'id' => true, 'lang' => true, 'dir' => true );
		return array(
			'p' => $c, 'em' => $c, 'strong' => $c, 'i' => $c, 'b' => $c, 'br' => array(), 'hr' => $c, 'sup' => $c, 'sub' => $c,
			'h1' => $c, 'h2' => $c, 'h3' => $c, 'h4' => $c, 'div' => $c, 'section' => $c, 'span' => $c, 'blockquote' => $c,
			'ul' => $c, 'ol' => $c, 'li' => $c, 'small' => $c, 'u' => $c, 's' => $c,
		);
	}

	/**
	 * @return array|WP_Error  [ 'he' => 'updated'|'same', ... ]
	 */
	public static function import( array $pkg, $source, $force = false ) {
		global $wpdb;
		$t       = RPB_DB::t( 'chapters' );
		$result  = array();
		$gen     = isset( $pkg['generated'] ) ? strtotime( $pkg['generated'] ) : time();
		$changes = get_option( 'rpb_changelog' );
		$changes = is_array( $changes ) ? $changes : array();

		$editions = array();
		foreach ( array( 'he', 'en' ) as $l ) {
			$editions[ $l ] = $pkg['books'][ $l ] ?? null;
			$editions[ $l . 'x' ] = $pkg['books_full'][ $l ] ?? null; // uncut edition, only for readers marked "full"
		}
		foreach ( $editions as $lang => $b ) {
			$base = substr( $lang, 0, 2 );
			if ( empty( $b['items'] ) || ! is_array( $b['items'] ) ) {
				if ( 3 === strlen( $lang ) && ! empty( $pkg['books'][ $base ]['items'] ) && RPB_DB::meta( $lang ) ) {
					// a package with one edition only: drop the old uncut edition so nobody reads a stale text
					delete_option( 'rpb_book_' . $lang );
					$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE lang = %s", $lang ) ); // phpcs:ignore
					$result[ $lang ] = 'removed';
				}
				continue;
			}
			$old = RPB_DB::meta( $lang );
			if ( $old && ! $force && $gen && ! empty( $old['generated_ts'] ) && $gen < (int) $old['generated_ts'] ) {
				$result[ $lang ] = 'older';
				continue;
			}
			$rows  = array();
			$words = 0;
			$pos   = 0;
			foreach ( $b['items'] as $it ) {
				$html = wp_kses( (string) ( $it['html'] ?? '' ), self::allowed_html() );
				if ( '' === trim( $html ) ) {
					continue;
				}
				$w      = (int) ( $it['words'] ?? str_word_count( wp_strip_all_tags( $html ) ) );
				$words += $w;
				$rows[] = array(
					'pos'   => $pos++,
					'ckey'  => substr( sanitize_key( $it['key'] ?? ( 'c' . $pos ) ), 0, 40 ),
					'kind'  => ( 'front' === ( $it['kind'] ?? '' ) ) ? 'front' : 'chapter',
					'part'  => mb_substr( sanitize_text_field( $it['part'] ?? '' ), 0, 190 ),
					'title' => mb_substr( sanitize_text_field( $it['title'] ?? '' ), 0, 255 ),
					'words' => $w,
					'html'  => $html,
				);
			}
			if ( ! $rows ) {
				continue;
			}
			$version = substr( sha1( wp_json_encode( $rows ) ), 0, 16 );
			if ( $old && $old['version'] === $version && ! $force ) {
				// Same text, but a new "what's new" note that should be shown: an announcement without a new version.
				$ann_note = sanitize_textarea_field( $pkg['note'][ $base ] ?? ( is_string( $pkg['note'] ?? null ) ? $pkg['note'] : '' ) );
				$ann      = '' !== $ann_note && empty( $pkg['silent'] ) && $ann_note !== ( $old['note'] ?? '' );
				if ( ! $ann ) {
					$result[ $lang ] = 'same';
					continue;
				}
				$old['ann']      = substr( $version, 0, 10 ) . '-' . base_convert( (string) time(), 10, 36 );
				$old['quiet']    = array( $old['ann'] );
				$old['note']     = $ann_note;
				$old['silent']   = 0;
				$old['imported'] = time();
				update_option( 'rpb_book_' . $lang, $old, false );
				array_unshift( $changes, array( 'lang' => $lang, 'version' => $version, 'at' => time(), 'note' => $ann_note . ' (הודעה לקוראים, הטקסט לא השתנה)', 'source' => $source, 'words' => (int) $old['words'] ) );
				$result[ $lang ] = 'announced';
				continue;
			}
			foreach ( $rows as $r ) {
				$r['lang']    = $lang;
				$r['version'] = $version;
				$ok           = $wpdb->insert( $t, $r );
				if ( false === $ok ) {
					$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE lang = %s AND version = %s", $lang, $version ) ); // phpcs:ignore
					return new WP_Error( 'rpb', 'שגיאת מסד נתונים בזמן שמירת הספר: ' . $wpdb->last_error );
				}
			}
			$note = sanitize_textarea_field( $pkg['note'][ $base ] ?? ( is_string( $pkg['note'] ?? null ) ? $pkg['note'] : '' ) );
			// Silent update = no "the book was updated" popup. Default: silent when there is no "what's new" note.
			$silent = isset( $pkg['silent'] ) ? ! empty( $pkg['silent'] ) : ( '' === $note );
			$quiet  = array( $version );
			$ann    = $version;
			if ( $silent && $old ) {
				$quiet = array_merge( ! empty( $old['quiet'] ) && is_array( $old['quiet'] ) ? $old['quiet'] : array( $old['version'] ), $quiet );
				$ann   = $old['ann'] ?? $old['version'];
			}
			$meta = array(
				'lang'         => $lang,
				'dir'          => 'rtl' === ( $b['dir'] ?? ( 'he' === $base ? 'rtl' : 'ltr' ) ) ? 'rtl' : 'ltr',
				'title'        => sanitize_text_field( $b['title'] ?? '' ),
				'subtitle'     => sanitize_text_field( $b['subtitle'] ?? '' ),
				'author'       => sanitize_text_field( $b['author'] ?? '' ),
				'version'      => $version,
				'generated'    => sanitize_text_field( $pkg['generated'] ?? '' ),
				'generated_ts' => $gen,
				'imported'     => time(),
				'source'       => $source,
				'chapters'     => count( $rows ),
				'words'        => $words,
				'note'         => $note,
				'silent'       => $silent ? 1 : 0,
				'ann'          => $ann,
				'quiet'        => array_slice( array_values( array_unique( $quiet ) ), -60 ),
			);
			update_option( 'rpb_book_' . $lang, $meta, false );
			if ( ! empty( $b['cover'] ) && preg_match( '#^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$#', $b['cover'] ) ) {
				update_option( 'rpb_cover_' . $lang, $b['cover'], false );
			}
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE lang = %s AND version <> %s", $lang, $version ) ); // phpcs:ignore
			array_unshift( $changes, array( 'lang' => $lang, 'version' => $version, 'at' => time(), 'note' => $silent ? trim( $note . ' (עדכון שקט, בלי הודעה לקוראים)' ) : $note, 'source' => $source, 'words' => $words ) );
			$result[ $lang ] = 'updated';
		}
		if ( ! $result ) {
			return new WP_Error( 'rpb', 'בחבילה לא נמצאו פרקים.' );
		}
		update_option( 'rpb_changelog', array_slice( $changes, 0, 60 ), false );
		update_option( 'rpb_last_import', array( 'at' => time(), 'source' => $source, 'result' => $result ), false );
		return $result;
	}

	/* ---------- automatic push ---------- */

	public static function push() {
		RPB_Bots::private_headers();
		$ip   = RPB_Access::ip();
		$fkey = 'rpb_pushfail_' . md5( $ip );
		if ( (int) get_transient( $fkey ) >= 10 ) {
			wp_send_json( array( 'ok' => false, 'error' => 'too many attempts' ), 429 );
		}
		$body = file_get_contents( 'php://input' ); // phpcs:ignore
		$pkg  = self::decode( (string) $body, true );
		if ( is_wp_error( $pkg ) ) {
			set_transient( $fkey, (int) get_transient( $fkey ) + 1, HOUR_IN_SECONDS );
			wp_send_json( array( 'ok' => false, 'error' => $pkg->get_error_message() ), 403 );
		}
		$res = self::import( $pkg, 'push' );
		if ( is_wp_error( $res ) ) {
			wp_send_json( array( 'ok' => false, 'error' => $res->get_error_message() ), 500 );
		}
		wp_send_json( array( 'ok' => true, 'result' => $res ) );
	}

	/* ---------- automatic pull ---------- */

	public static function pull( $manual = false ) {
		$url = trim( (string) RPB_Settings::get( 'pull_url' ) );
		if ( ! $url || ! wp_http_validate_url( $url ) ) {
			return new WP_Error( 'rpb', 'לא הוגדרה כתובת לבדיקת עדכונים.' );
		}
		$state = get_option( 'rpb_pull_state' );
		$state = is_array( $state ) ? $state : array();
		$args  = array( 'timeout' => 45, 'redirection' => 5, 'headers' => array() );
		if ( ! $manual && ! empty( $state['etag'] ) && ( $state['url'] ?? '' ) === $url ) {
			$args['headers']['If-None-Match'] = $state['etag'];
		}
		$r = wp_safe_remote_get( $url, $args );
		$state['checked'] = time();
		$state['url']     = $url;
		if ( is_wp_error( $r ) ) {
			$state['error'] = $r->get_error_message();
			update_option( 'rpb_pull_state', $state, false );
			return $r;
		}
		$code = wp_remote_retrieve_response_code( $r );
		if ( 304 === $code ) {
			$state['error'] = '';
			update_option( 'rpb_pull_state', $state, false );
			return array( 'none' => 'same' );
		}
		if ( 200 !== $code ) {
			$state['error'] = 'HTTP ' . $code;
			update_option( 'rpb_pull_state', $state, false );
			return new WP_Error( 'rpb', 'הכתובת החזירה שגיאה ' . $code );
		}
		$body = wp_remote_retrieve_body( $r );
		$hash = sha1( $body );
		if ( ! $manual && ( $state['hash'] ?? '' ) === $hash ) {
			$state['error'] = '';
			update_option( 'rpb_pull_state', $state, false );
			return array( 'none' => 'same' );
		}
		$pkg = self::decode( $body, true );
		if ( is_wp_error( $pkg ) ) {
			$state['error'] = $pkg->get_error_message();
			update_option( 'rpb_pull_state', $state, false );
			return $pkg;
		}
		$res = self::import( $pkg, 'pull' );
		if ( ! is_wp_error( $res ) ) {
			$state['hash']  = $hash;
			$state['etag']  = wp_remote_retrieve_header( $r, 'etag' );
			$state['error'] = '';
		} else {
			$state['error'] = $res->get_error_message();
		}
		update_option( 'rpb_pull_state', $state, false );
		return $res;
	}
}
