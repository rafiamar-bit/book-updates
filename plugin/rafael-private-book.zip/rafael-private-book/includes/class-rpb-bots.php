<?php
/**
 * File: includes/class-rpb-bots.php
 * Keeps search engines and AI crawlers away: robots.txt rules, /ai.txt, "noai" headers,
 * and a hard 403 for known AI crawlers (on the book pages always, on the whole site if enabled).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Bots {

	/** Known AI training / AI answer crawlers (user-agent tokens). */
	public static function ai_agents() {
		return array(
			'GPTBot', 'ChatGPT-User', 'OAI-SearchBot', 'ClaudeBot', 'Claude-Web', 'Claude-User', 'Claude-SearchBot', 'anthropic-ai',
			'CCBot', 'Google-Extended', 'GoogleOther', 'Google-CloudVertexBot', 'Gemini-Deep-Research', 'Applebot-Extended',
			'PerplexityBot', 'Perplexity-User', 'Bytespider', 'TikTokSpider', 'Amazonbot', 'meta-externalagent', 'meta-externalfetcher',
			'FacebookBot', 'cohere-ai', 'cohere-training-data-crawler', 'Diffbot', 'Omgilibot', 'Omgili', 'YouBot', 'ImagesiftBot',
			'Timpibot', 'AI2Bot', 'Ai2Bot-Dolma', 'DuckAssistBot', 'MistralAI-User', 'PetalBot', 'Scrapy', 'img2dataset', 'Kangaroo Bot',
			'Webzio-Extended', 'iaskspider', 'PanguBot', 'Sidetrade indexer bot', 'VelenPublicWebCrawler', 'Quora-Bot', 'NovaAct',
			'Brightbot', 'FirecrawlAgent', 'Crawl4AI', 'archive.org_bot', 'ia_archiver', 'magpie-crawler', 'Factset_spyderbot',
		);
	}

	public static function init() {
		add_filter( 'robots_txt', array( __CLASS__, 'robots_txt' ), 99, 2 );
		add_action( 'init', array( __CLASS__, 'ai_txt' ), 0 );
		add_action( 'init', array( __CLASS__, 'block_sitewide' ), 1 );
		add_filter( 'wp_headers', array( __CLASS__, 'site_headers' ) );
	}

	public static function is_ai_agent( $ua = null ) {
		if ( null === $ua ) {
			$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		}
		foreach ( self::ai_agents() as $bot ) {
			if ( false !== stripos( $ua, $bot ) ) {
				return true;
			}
		}
		return false;
	}

	/** Headless browsers and generic scrapers are not welcome on the book pages. */
	public static function is_scraper( $ua = null ) {
		if ( null === $ua ) {
			$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
		}
		if ( '' === trim( $ua ) ) {
			return true;
		}
		foreach ( array( 'HeadlessChrome', 'PhantomJS', 'python-requests', 'python-urllib', 'aiohttp', 'httpx', 'curl/', 'Wget', 'Go-http-client', 'node-fetch', 'axios/', 'okhttp', 'libwww-perl', 'Java/', 'HTTrack', 'Puppeteer', 'Playwright', 'Selenium' ) as $s ) {
			if ( false !== stripos( $ua, $s ) ) {
				return true;
			}
		}
		return self::is_ai_agent( $ua );
	}

	public static function robots_txt( $output, $public ) {
		// Never name the book's address here: robots.txt is public and must not point anyone to the book.
		// The book is protected without it (no public text, noindex headers, 403 for AI crawlers).
		$rules = "\n# Personal links are private.\nUser-agent: *\nDisallow: /*?k=\nDisallow: /*&k=\n";
		if ( RPB_Settings::get( 'block_ai_sitewide' ) ) {
			$rules .= "\n# No AI training or AI answers from anything on this site.\n";
			foreach ( self::ai_agents() as $bot ) {
				$rules .= "User-agent: $bot\n";
			}
			$rules .= "Disallow: /\n";
		}
		return $output . $rules;
	}

	/** Serves /ai.txt (Spawning convention) when no real file exists. */
	public static function ai_txt() {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		$home = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( rtrim( (string) $home, '/' ) . '/ai.txt' !== $path ) {
			return;
		}
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo "# ai.txt: permissions for AI training and generation\n";
		echo "# The book on this site is unpublished, copyrighted work. All rights reserved.\n";
		if ( RPB_Settings::get( 'block_ai_sitewide' ) ) {
			echo "User-Agent: *\nDisallow: /\nDisallow: *\n";
		} else {
			echo "User-Agent: *\nDisallow: /*?k=\n";
		}
		exit;
	}

	public static function block_sitewide() {
		if ( RPB_Settings::get( 'block_ai_sitewide' ) && ! is_admin() && self::is_ai_agent() ) {
			status_header( 403 );
			header( 'X-Robots-Tag: noindex, nofollow, noarchive, nosnippet, noai, noimageai' );
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo 'AI crawling of this site is not permitted.';
			exit;
		}
	}

	public static function site_headers( $headers ) {
		if ( RPB_Settings::get( 'block_ai_sitewide' ) ) {
			$headers['X-Robots-Tag'] = isset( $headers['X-Robots-Tag'] ) ? $headers['X-Robots-Tag'] . ', noai, noimageai' : 'noai, noimageai';
		}
		return $headers;
	}

	/** Strong "private" headers for every book response. */
	public static function private_headers() {
		nocache_headers();
		header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate, noai, noimageai' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Frame-Options: DENY' );
		header( 'X-Content-Type-Options: nosniff' );
		header( "Content-Security-Policy: frame-ancestors 'none'" );
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // page-cache plugins must never store a reader's page
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
	}
}
