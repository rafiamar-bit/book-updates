<?php
/**
 * File: includes/class-rpb-front.php
 * Public routes of the book address (default /book/):
 *   /book/               landing page (or the reader, when this browser has a valid reader session)
 *   /book/?k=TOKEN       personal welcome page -> "start reading" button (POST) -> reader
 *   /book/?cover=he|en   cover image (public, used by the landing page and link previews)
 *   /book/?landing=1     landing page even with a session;  ?lang=en  English landing
 *   /book/?logout=1      ends the session on this device
 * The plugin never touches the site's home page, menus, sitemaps or feeds: the book is reachable only by its address.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Front {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'route' ), 20 );
	}

	private static function is_book_request() {
		if ( isset( $_GET['rpb'] ) ) { // phpcs:ignore
			return true;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$path = trim( substr( $uri, strlen( $home ) ), '/' );
		return 0 === strpos( $uri, $home ) && $path === RPB_Settings::slug();
	}

	public static function route() {
		if ( is_admin() || wp_doing_ajax() || ! self::is_book_request() ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification
		if ( isset( $_GET['cover'] ) ) {
			self::cover( sanitize_key( $_GET['cover'] ) );
		}
		RPB_Bots::private_headers();
		if ( isset( $_GET['privacy'] ) ) {
			self::render( 'privacy', array( 'lang' => ( isset( $_GET['lang'] ) && 'en' === $_GET['lang'] ) ? 'en' : 'he' ) );
		}
		if ( RPB_Bots::is_ai_agent() ) {
			self::message( 403, 'blocked' );
		}
		$lang = ( isset( $_REQUEST['lang'] ) && 'en' === $_REQUEST['lang'] ) ? 'en' : 'he';

		if ( isset( $_GET['logout'] ) ) {
			RPB_Access::end_session();
			wp_safe_redirect( RPB_Settings::book_url(), 303 );
			exit;
		}

		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			$do = sanitize_key( $_POST['rpb_do'] ?? '' );
			if ( 'open' === $do ) {
				$inv = RPB_Access::invite_by_token( wp_unslash( $_POST['k'] ?? '' ) );
				$err = RPB_Access::open( $inv );
				if ( $err ) {
					self::message( 'limit' === $err ? 403 : 410, $err, $inv ? self::invite_lang( $inv ) : $lang );
				}
				$read = sanitize_key( wp_unslash( $_POST['read'] ?? '' ) );
				$read = in_array( $read, RPB_Access::langs_for( $inv['lang'] ), true ) ? $read : '';
				if ( $read ) { // the reader chose a language on the welcome page: start the book in it
					$pr         = json_decode( (string) $inv['progress'], true );
					$pr         = is_array( $pr ) ? $pr : array();
					$pr['last'] = $read;
					RPB_Access::update_invite( $inv['id'], array( 'progress' => wp_json_encode( $pr ) ) );
				}
				wp_safe_redirect( RPB_Settings::book_url( $read ? array( 'read' => $read ) : array() ), 303 );
				exit;
			}
			if ( 'request' === $do ) {
				$kind = ( 'launch' === ( $_POST['kind'] ?? '' ) ) ? 'launch' : 'access';
				$sent = RPB_Notify::handle_request( $lang );
				$args = array( 'sent' => 'busy' === $sent ? 'busy' : ( $sent ? $kind : 'err' ) );
				if ( 'en' === $lang ) {
					$args['lang'] = 'en';
				}
				wp_safe_redirect( RPB_Settings::book_url( $args ) . ( 'launch' === $kind ? '#launch' : '#invite' ), 303 );
				exit;
			}
		}

		if ( isset( $_GET['k'] ) ) {
			$inv = RPB_Access::invite_by_token( wp_unslash( $_GET['k'] ) );
			$err = RPB_Access::invite_problem( $inv );
			if ( $err ) {
				if ( $inv ) {
					RPB_DB::log( $inv['id'], 'denied', '', $err );
				}
				self::message( 'missing' === $err ? 404 : 410, $err, $inv ? self::invite_lang( $inv ) : $lang );
			}
			self::render( 'welcome', array( 'invite' => $inv, 'lang' => self::invite_lang( $inv ) ) );
		}

		$reader = RPB_Access::current();
		if ( $reader && ! isset( $_GET['landing'] ) && ! RPB_Bots::is_scraper() ) {
			if ( ! $reader['langs'] ) {
				self::message( 503, 'empty', $lang );
			}
			self::render( 'reader', array( 'reader' => $reader ) );
		}
		self::landing( $lang );
		// phpcs:enable
	}

	public static function landing( $lang, $is_home = false ) {
		if ( RPB_Settings::get( 'landing_index' ) ) {
			nocache_headers();
			header( 'X-Robots-Tag: noarchive, noai, noimageai' );
		} else {
			RPB_Bots::private_headers();
		}
		self::render( 'landing', array( 'lang' => $lang, 'is_home' => $is_home ) );
	}

	public static function invite_lang( $inv ) {
		return ( $inv && 'en' === $inv['lang'] ) ? 'en' : 'he';
	}

	public static function cover_url( $lang ) {
		$m = RPB_DB::meta( $lang );
		$v = $m ? substr( $m['version'], 0, 8 ) : '0';
		return RPB_Settings::book_url( array( 'cover' => $lang, 'v' => $v ) );
	}

	public static function has_cover( $lang ) {
		return (bool) get_option( 'rpb_cover_' . $lang );
	}

	private static function cover( $lang ) {
		$lang = in_array( $lang, array( 'he', 'en' ), true ) ? $lang : 'he';
		$data = get_option( 'rpb_cover_' . $lang );
		if ( ! $data ) {
			$data = get_option( 'rpb_cover_' . ( 'he' === $lang ? 'en' : 'he' ) );
		}
		if ( ! $data || ! preg_match( '#^data:(image/[a-z]+);base64,(.+)$#', $data, $m ) ) {
			status_header( 404 );
			exit;
		}
		$bin = base64_decode( $m[2] );
		header( 'Content-Type: ' . $m[1] );
		header( 'Content-Length: ' . strlen( $bin ) );
		header( 'Cache-Control: public, max-age=86400' );
		header( 'X-Robots-Tag: noimageai, noai' );
		echo $bin; // phpcs:ignore
		exit;
	}

	public static function message( $status, $code, $lang = 'he' ) {
		status_header( is_int( $status ) ? $status : 403 );
		self::render( 'message', array( 'code' => $code, 'lang' => $lang ) );
	}

	public static function render( $template, array $vars ) {
		header( 'Content-Type: text/html; charset=utf-8' );
		extract( $vars, EXTR_SKIP ); // phpcs:ignore
		include RPB_DIR . 'templates/' . $template . '.php';
		exit;
	}

	/** Small helper for templates: pick Hebrew or English. */
	public static function t( $lang, $he, $en ) {
		return 'en' === $lang ? $en : $he;
	}

	public static function book_title( $lang ) {
		$m = RPB_DB::meta( $lang );
		if ( $m && $m['title'] ) {
			return $m['title'];
		}
		return 'en' === $lang ? 'Half an Inch' : 'חצי סנטימטר';
	}

}
