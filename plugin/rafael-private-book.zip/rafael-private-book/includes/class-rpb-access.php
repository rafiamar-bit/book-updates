<?php
/**
 * File: includes/class-rpb-access.php
 * Personal invite links, device limits, signed reader sessions (HttpOnly cookie), CSRF and rate limiting.
 *
 * Flow: personal link (?k=TOKEN) -> welcome page -> "start reading" (POST) -> device registered,
 * signed cookie set, redirect to the clean book address (the token leaves the address bar).
 * Link-preview robots (WhatsApp, Telegram...) only see the welcome page and never use up a device.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RPB_Access {

	const COOKIE_SESSION = 'rpb_s';
	const COOKIE_DEVICE  = 'rpb_d';

	private static $current = false;

	public static function ip() {
		return isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 64 ) : '';
	}

	/* ---------- invites ---------- */

	public static function create_invite( array $d ) {
		global $wpdb;
		$token = RPB_Settings::random( 18 );
		$row   = array(
			'token'       => $token,
			'name'        => mb_substr( sanitize_text_field( $d['name'] ?? '' ), 0, 190 ),
			'email'       => sanitize_email( $d['email'] ?? '' ),
			'phone'       => preg_replace( '/[^0-9+]/', '', (string) ( $d['phone'] ?? '' ) ),
			'lang'        => in_array( $d['lang'] ?? 'both', array( 'he', 'en', 'both' ), true ) ? $d['lang'] : 'both',
			'note'        => sanitize_textarea_field( $d['note'] ?? '' ),
			'max_devices' => max( 0, min( 50, (int) ( $d['max_devices'] ?? RPB_Settings::get( 'max_devices' ) ) ) ),
			'max_chapters' => max( 0, min( 999, (int) ( $d['max_chapters'] ?? 0 ) ) ),
			'devices'     => '[]',
			'expires_at'  => ! empty( $d['expires_at'] ) ? gmdate( 'Y-m-d 23:59:59', strtotime( $d['expires_at'] ) ) : null,
			'created_at'  => RPB_DB::now(),
			'progress'    => '{}',
		);
		$wpdb->insert( RPB_DB::t( 'invites' ), $row );
		return (int) $wpdb->insert_id;
	}

	public static function invite( $id ) {
		global $wpdb;
		$t = RPB_DB::t( 'invites' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
	}

	public static function invite_by_token( $token ) {
		global $wpdb;
		$token = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $token );
		if ( strlen( $token ) < 16 ) {
			return null;
		}
		$t   = RPB_DB::t( 'invites' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE token = %s", $token ), ARRAY_A ); // phpcs:ignore
		return ( $row && hash_equals( $row['token'], $token ) ) ? $row : null;
	}

	/** '' when usable, otherwise 'revoked' / 'expired'. */
	public static function invite_problem( $inv ) {
		if ( ! $inv ) {
			return 'missing';
		}
		if ( (int) $inv['revoked'] ) {
			return 'revoked';
		}
		if ( ! empty( $inv['expires_at'] ) && strtotime( $inv['expires_at'] . ' UTC' ) < time() ) {
			return 'expired';
		}
		return '';
	}

	public static function update_invite( $id, array $data ) {
		global $wpdb;
		return $wpdb->update( RPB_DB::t( 'invites' ), $data, array( 'id' => (int) $id ) );
	}

	public static function devices( $inv ) {
		$d = json_decode( (string) $inv['devices'], true );
		return is_array( $d ) ? $d : array();
	}

	/** Langs an invite may read, limited to the languages actually uploaded. */
	public static function langs_for( $inv_lang ) {
		$have = RPB_DB::languages();
		$want = 'both' === $inv_lang ? array( 'he', 'en' ) : array( $inv_lang );
		$out  = array_values( array_intersect( $want, $have ) );
		return $out ? $out : $have;
	}

	/* ---------- opening a link ---------- */

	/** Registers this device on the invite and sets the session cookie. Returns '' or an error code. */
	public static function open( $inv ) {
		$problem = self::invite_problem( $inv );
		if ( $problem ) {
			return $problem;
		}
		$device = self::device_id();
		$list   = self::devices( $inv );
		$known  = false;
		foreach ( $list as &$dv ) {
			if ( hash_equals( (string) $dv['id'], $device ) ) {
				$known     = true;
				$dv['seen'] = time();
			}
		}
		unset( $dv );
		if ( ! $known ) {
			$max = (int) $inv['max_devices'];
			if ( $max > 0 && count( $list ) >= $max ) {
				RPB_DB::log( $inv['id'], 'limit', '', 'devices ' . count( $list ) . '/' . $max );
				return 'limit';
			}
			$list[] = array(
				'id'    => $device,
				'first' => time(),
				'seen'  => time(),
				'ua'    => mb_substr( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '', 0, 160 ),
			);
		}
		$upd = array(
			'devices'   => wp_json_encode( $list ),
			'opens'     => (int) $inv['opens'] + 1,
			'last_seen' => RPB_DB::now(),
		);
		if ( empty( $inv['first_open'] ) ) {
			$upd['first_open'] = RPB_DB::now();
		}
		self::update_invite( $inv['id'], $upd );
		RPB_DB::log( $inv['id'], 'open', '', $known ? 'known device' : 'new device' );
		self::set_session( (int) $inv['id'], $device );
		return '';
	}

	public static function device_id() {
		$d = isset( $_COOKIE[ self::COOKIE_DEVICE ] ) ? preg_replace( '/[^A-Za-z0-9_-]/', '', wp_unslash( $_COOKIE[ self::COOKIE_DEVICE ] ) ) : '';
		if ( strlen( $d ) < 20 ) {
			$d = RPB_Settings::random( 18 );
		}
		self::cookie( self::COOKIE_DEVICE, $d, time() + 5 * YEAR_IN_SECONDS );
		return $d;
	}

	private static function cookie( $name, $value, $expires ) {
		$secure = is_ssl();
		if ( PHP_VERSION_ID >= 70300 ) {
			setcookie( $name, $value, array( 'expires' => $expires, 'path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax' ) );
		} else {
			setcookie( $name, $value, $expires, '/; samesite=Lax', '', $secure, true );
		}
		$_COOKIE[ $name ] = $value;
	}

	private static function sign( $payload ) {
		return hash_hmac( 'sha256', $payload, RPB_Settings::cookie_key() );
	}

	public static function set_session( $invite_id, $device ) {
		$exp     = time() + max( 1, (int) RPB_Settings::get( 'session_days' ) ) * DAY_IN_SECONDS;
		$payload = rtrim( strtr( base64_encode( wp_json_encode( array( 'i' => $invite_id, 'd' => $device, 'e' => $exp ) ) ), '+/', '-_' ), '=' );
		self::cookie( self::COOKIE_SESSION, $payload . '.' . self::sign( $payload ), $exp );
		self::$current = false;
	}

	public static function end_session() {
		self::cookie( self::COOKIE_SESSION, '', time() - 3600 );
		self::$current = null;
	}

	/**
	 * The current reader, or null. Shape: [ 'invite' => row|null, 'device' => id, 'preview' => bool, 'name' => str, 'langs' => [] ].
	 * A logged-in site admin can always open the book (preview mode, nothing is logged).
	 */
	public static function current() {
		if ( false !== self::$current ) {
			return self::$current;
		}
		self::$current = null;
		$raw           = isset( $_COOKIE[ self::COOKIE_SESSION ] ) ? (string) wp_unslash( $_COOKIE[ self::COOKIE_SESSION ] ) : '';
		if ( $raw && false !== strpos( $raw, '.' ) ) {
			list( $payload, $sig ) = explode( '.', $raw, 2 );
			if ( hash_equals( self::sign( $payload ), (string) $sig ) ) {
				$data = json_decode( base64_decode( strtr( $payload, '-_', '+/' ) ), true );
				if ( is_array( $data ) && (int) $data['e'] > time() ) {
					$inv = self::invite( (int) $data['i'] );
					if ( $inv && ! self::invite_problem( $inv ) ) {
						foreach ( self::devices( $inv ) as $dv ) {
							if ( hash_equals( (string) $dv['id'], (string) $data['d'] ) ) {
								self::$current = array(
									'invite'  => $inv,
									'device'  => (string) $data['d'],
									'preview' => false,
									'name'    => $inv['name'],
									'langs'   => self::langs_for( $inv['lang'] ),
								);
								return self::$current;
							}
						}
					}
				}
			}
		}
		if ( is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			self::$current = array(
				'invite'  => null,
				'device'  => 'admin',
				'preview' => true,
				'name'    => '',
				'langs'   => RPB_DB::languages(),
			);
		}
		return self::$current;
	}

	public static function csrf( $reader ) {
		$id = $reader['invite'] ? $reader['invite']['id'] : 'admin' . get_current_user_id();
		return substr( self::sign( 'csrf|' . $id . '|' . $reader['device'] ), 0, 32 );
	}

	/** Simple per-reader limit against scraping scripts: $max requests per minute. */
	public static function rate_ok( $reader, $bucket, $max, $window = 60 ) {
		$id  = $reader['invite'] ? 'i' . $reader['invite']['id'] : 'a';
		$key = 'rpb_rl_' . md5( $bucket . $id . floor( time() / $window ) );
		$n   = (int) get_transient( $key );
		if ( $n >= $max ) {
			return false;
		}
		set_transient( $key, $n + 1, $window + 30 );
		return true;
	}

	/* ---------- invisible per-reader fingerprint ---------- */

	const ZW0 = "\u{200C}";
	const ZW1 = "\u{200D}";
	const ZWM = "\u{2063}";

	public static function fingerprint( $invite_id ) {
		$bits = str_pad( decbin( (int) $invite_id & 0xFFFF ), 16, '0', STR_PAD_LEFT );
		return self::ZWM . strtr( $bits, array( '0' => self::ZW0, '1' => self::ZW1 ) ) . self::ZWM;
	}

	/** Adds the reader's invisible fingerprint at the end of every 4th paragraph. */
	public static function mark_html( $html, $invite_id ) {
		if ( ! $invite_id ) {
			return $html;
		}
		$fp = self::fingerprint( $invite_id );
		$n  = 0;
		return preg_replace_callback(
			'#</p>#',
			function ( $m ) use ( &$n, $fp ) {
				return ( 0 === ( $n++ % 4 ) ) ? $fp . '</p>' : '</p>';
			},
			$html
		);
	}

	/** Finds reader ids hidden in pasted text. */
	public static function trace( $text ) {
		$ids = array();
		if ( preg_match_all( '/' . self::ZWM . '([' . self::ZW0 . self::ZW1 . ']{16})' . self::ZWM . '/u', $text, $m ) ) {
			foreach ( $m[1] as $seq ) {
				$bits         = strtr( $seq, array( self::ZW0 => '0', self::ZW1 => '1' ) );
				$id           = bindec( $bits );
				$ids[ $id ]   = ( $ids[ $id ] ?? 0 ) + 1;
			}
		}
		return $ids;
	}
}
