<?php
/**
 * File: rafael-private-book.php
 *
 * Plugin Name:       ספר פרטי – חצי סנטימטר
 * Plugin URI:        https://rafaelamar.site/
 * Description:       קורא ספר דיגיטלי פרטי (עברית ואנגלית) בגישה עם קישור אישי בלבד. חסום למנועי חיפוש ולבוטים של בינה מלאכותית, מתעדכן מיד בכל בנייה חדשה של הספר, עם עמוד נחיתה, יומן כניסות והודעות עדכון לקוראים.
 * Version:           1.3.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Rafael Amar
 * License:           Proprietary – all rights reserved
 * Text Domain:       rafael-private-book
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RPB_VERSION', '1.3.1' );
define( 'RPB_DB_VERSION', '6' );
define( 'RPB_FILE', __FILE__ );
define( 'RPB_DIR', plugin_dir_path( __FILE__ ) );
define( 'RPB_URL', plugin_dir_url( __FILE__ ) );

require_once RPB_DIR . 'includes/class-rpb-db.php';
require_once RPB_DIR . 'includes/class-rpb-settings.php';
require_once RPB_DIR . 'includes/class-rpb-access.php';
require_once RPB_DIR . 'includes/class-rpb-bots.php';
require_once RPB_DIR . 'includes/class-rpb-import.php';
require_once RPB_DIR . 'includes/class-rpb-front.php';
require_once RPB_DIR . 'includes/class-rpb-ajax.php';
require_once RPB_DIR . 'includes/class-rpb-notify.php';
if ( is_admin() ) {
	require_once RPB_DIR . 'includes/class-rpb-admin.php';
}

register_activation_hook( __FILE__, array( 'RPB_DB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'RPB_DB', 'deactivate' ) );

add_filter( 'cron_schedules', array( 'RPB_DB', 'schedules' ) );
add_action( 'plugins_loaded', array( 'RPB_DB', 'maybe_upgrade' ) );
RPB_Bots::init();
RPB_Import::init();
RPB_Front::init();
RPB_Ajax::init();
if ( is_admin() ) {
	RPB_Admin::init();
}
