<?php
/**
 * File: templates/welcome.php
 * What a personal link opens: a short personal welcome and one button. Pressing it (POST) registers
 * this device and opens the book. Link-preview robots (WhatsApp etc.) see only this page.
 *
 * @var array  $invite
 * @var string $lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$en     = ( 'en' === $lang );
$T      = function ( $he, $e ) use ( $en ) { return $en ? $e : $he; };
$s      = RPB_Settings::all();
$title  = RPB_Front::book_title( $lang );
$author = $en ? $s['author_en'] : $s['author_he'];
$name   = trim( (string) $invite['name'] );
$langs  = RPB_Access::langs_for( $invite['lang'] );
$cover  = ( RPB_Front::has_cover( $lang ) || RPB_Front::has_cover( $en ? 'he' : 'en' ) ) ? RPB_Front::cover_url( $lang ) : '';
?><!doctype html>
<html lang="<?php echo $en ? 'en' : 'he'; ?>" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noai, noimageai">
<meta name="referrer" content="no-referrer">
<title><?php echo esc_html( $title . ' · ' . $T( 'הזמנה אישית', 'A personal invitation' ) ); ?></title>
<meta property="og:title" content="<?php echo esc_attr( $title . ' · ' . $T( 'הזמנה אישית לקריאה', 'A personal invitation to read' ) ); ?>">
<meta property="og:description" content="<?php echo esc_attr( $T( 'רומן מאת ', 'A novel by ' ) . $author ); ?>">
<?php if ( $cover ) : ?><meta property="og:image" content="<?php echo esc_url( $cover ); ?>"><?php endif; ?>
<meta name="theme-color" content="#07070a">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Karantina:wght@300;400;700&family=Big+Shoulders+Display:wght@300;800;900&family=Noto+Serif+Hebrew:wght@300;400;600&family=JetBrains+Mono:wght@400;600&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( RPB_URL . 'assets/landing.css?v=' . RPB_VERSION ); ?>">
<style>
.solo{min-height:100svh;display:grid;place-items:center;padding:40px var(--gut);text-align:center}
.solo-in{max-width:560px}
.solo .mini{width:min(56vw,230px);margin:0 auto 34px;aspect-ratio:700/993;object-fit:cover;border-radius:3px 5px 5px 3px;box-shadow:0 30px 60px -25px rgba(0,0,0,.9),0 0 80px -20px rgba(232,162,176,.25)}
.solo h1{font-family:var(--display);font-weight:400;font-size:clamp(34px,4vw + 14px,56px);line-height:1.1;margin:0 0 12px}
.solo p{color:#d6cdc0;margin:0 auto 28px;max-width:40ch}
.solo .fine{font-size:14px;color:var(--dim);margin-top:26px}
.solo .pick{margin:0 auto 14px;color:var(--ink);font-family:var(--display);font-size:clamp(26px,2.4vw,34px);line-height:1.1}
.solo .pick span{display:block;font-family:var(--mono);font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin-top:6px}
.solo .langs{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.solo .langs .btn{min-width:200px}
.solo .langs .btn[lang=en]{font-family:var(--mono);font-size:13px;letter-spacing:.14em;text-transform:uppercase;font-weight:600}
.solo .fine2{font-size:14px;color:var(--dim);margin:14px auto 0}
</style>
</head>
<body class="<?php echo $en ? 'en' : 'he'; ?>">
<main class="solo">
	<div class="solo-in">
		<?php if ( $cover ) : ?><img class="mini" src="<?php echo esc_url( $cover ); ?>" alt="" draggable="false"><?php endif; ?>
		<p class="eyebrow"><?php echo esc_html( $T( 'הזמנה אישית', 'A personal invitation' ) ); ?></p>
		<h1><?php
		if ( $name ) {
			echo esc_html( $T( $name . ', הספר מחכה לך', $name . ', the book is waiting for you' ) );
		} else {
			echo esc_html( $T( 'הספר מחכה לך', 'The book is waiting for you' ) );
		}
		?></h1>
		<p><?php echo esc_html( $T( $author . ' מזמין אותך לקרוא את "' . $title . '" לפני שהוא יוצא לאור. הקישור הזה אישי, רק בשבילך.', $author . ' invites you to read "' . $title . '" before it is published. This link is personal, just for you.' ) ); ?></p>
		<form method="post" action="<?php echo esc_url( RPB_Settings::book_url() ); ?>">
			<input type="hidden" name="rpb_do" value="open">
			<input type="hidden" name="k" value="<?php echo esc_attr( $invite['token'] ); ?>">
			<?php if ( count( $langs ) > 1 ) : ?>
				<p class="pick"><?php echo esc_html( $T( 'באיזו שפה לקרוא?', 'Which language?' ) ); ?> <span lang="<?php echo $en ? 'he' : 'en'; ?>" dir="<?php echo $en ? 'rtl' : 'ltr'; ?>"><?php echo esc_html( $en ? 'באיזו שפה לקרוא?' : 'Which language?' ); ?></span></p>
				<div class="langs">
					<button class="btn primary" type="submit" name="read" value="he" lang="he">לקרוא בעברית</button>
					<button class="btn primary" type="submit" name="read" value="en" lang="en">Read in English</button>
				</div>
				<p class="fine2"><?php echo esc_html( $T( 'אפשר לעבור בין השפות בכל רגע, גם באמצע פרק.', 'You can switch languages at any moment, even mid-chapter.' ) ); ?></p>
			<?php else : ?>
				<button class="btn primary" type="submit" name="read" value="<?php echo esc_attr( $langs[0] ?? $lang ); ?>"><?php echo esc_html( $T( 'להתחיל לקרוא', 'Start reading' ) ); ?></button>
			<?php endif; ?>
		</form>
		<p class="fine"><?php echo esc_html( $T( 'בבקשה לא להעביר את הקישור הלאה. הספר עוד לא יצא לאור, וכל עותק נושא את שמך.', 'Please don\'t forward this link. The book is not yet published, and every copy carries your name.' ) ); ?></p>
	</div>
</main>
</body>
</html>
