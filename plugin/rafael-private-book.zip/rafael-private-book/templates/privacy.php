<?php
/**
 * File: templates/privacy.php
 * Privacy policy (Israeli Privacy Protection Law incl. Amendment 13, anti-spam law) and accessibility statement (IS 5568).
 *
 * @var string $lang
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$en     = ( 'en' === $lang );
$s      = RPB_Settings::all();
$author = $en ? $s['author_en'] : $s['author_he'];
$mail   = RPB_Settings::contact_email();
$back   = RPB_Settings::book_url( $en ? array( 'lang' => 'en', 'landing' => 1 ) : array( 'landing' => 1 ) );
?><!doctype html>
<html lang="<?php echo $en ? 'en' : 'he'; ?>" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow">
<title><?php echo esc_html( $en ? 'Privacy & accessibility' : 'פרטיות ונגישות' ); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Karantina:wght@300;400;700&family=Big+Shoulders+Display:wght@300;800;900&family=Noto+Serif+Hebrew:wght@300;400;600&family=JetBrains+Mono:wght@400;600&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( RPB_URL . 'assets/landing.css?v=' . RPB_VERSION ); ?>">
<style>.doc{max-width:760px;margin:0 auto;padding:60px var(--gut) 80px}.doc h1{font-family:var(--display);font-weight:400;font-size:44px;margin:0 0 10px}.doc h2{font-family:var(--display);font-weight:400;font-size:28px;margin:46px 0 8px;color:var(--pink2)}.doc p,.doc li{color:#d6cdc0}.doc a{color:var(--pink2)}</style>
</head>
<body class="<?php echo $en ? 'en' : 'he'; ?>">
<main class="doc">
<p><a href="<?php echo esc_url( $back ); ?>"><?php echo $en ? '← Back to the book' : '→ חזרה לעמוד הספר'; ?></a></p>
<?php if ( $en ) : ?>
<h1>Privacy policy</h1>
<p>This page belongs to <?php echo esc_html( $author ); ?>, author of <em>Half an Inch</em>. Contact: <a href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?></a>.</p>
<h2>What we collect and why</h2>
<ul><li>Launch list and early-reading requests: your name, email (and anything you choose to write), the language of the page, and the time. Used only to contact you about the book.</li>
<li>Marketing emails (such as the launch offer) are sent only if you ticked the separate, optional consent box.</li>
<li>Readers with a personal link: the pages and chapters opened, reading position, device type and IP address, to keep the unpublished book safe and to know how far you got. Notes you send are seen by the author only.</li></ul>
<p>Giving this information is not required by law, but without it we cannot contact you or give you access. Nothing is sold or shared with third parties. Data is kept on this website's server; the access log is deleted after six months.</p>
<h2>Your rights</h2>
<p>You may ask to see, correct or delete your information, or unsubscribe at any time, by writing to the address above or using the link in any message.</p>
<h2 id="a11y">Accessibility statement</h2>
<p>We aim for this site to meet Israeli Standard 5568 / WCAG 2.0 AA: full keyboard navigation, screen-reader labels, readable contrast, adjustable text size in the reader, and respect for reduced-motion settings. If something is hard to use, please write to <a href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?></a> and we will fix it.</p>
<?php else : ?>
<h1>מדיניות פרטיות</h1>
<p>האתר שייך ל<?php echo esc_html( $author ); ?>, מחבר הרומן "חצי סנטימטר". ליצירת קשר: <a href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?></a>.</p>
<h2>איזה מידע נאסף ולמה</h2>
<ul><li>בהרשמה למחיר השקה ובבקשת קריאה מוקדמת נשמרים השם, המייל, מה שבחרת לכתוב, שפת העמוד והשעה. המידע משמש רק כדי ליצור איתך קשר בנוגע לספר.</li>
<li>דיוור ודברי פרסומת (כמו הצעת מחיר ההשקה) נשלחים רק למי שסימן/ה את תיבת ההסכמה הנפרדת, שאינה חובה.</li>
<li>אצל קוראים עם קישור אישי נשמרים העמודים והפרקים שנפתחו, מקום הקריאה, סוג המכשיר וכתובת ה־IP. המטרה היא לשמור על הספר, שעוד לא יצא לאור, ולדעת עד איפה הגעת. הערות שנשלחות מתוך הספר מגיעות רק לסופר.</li></ul>
<p>מסירת המידע אינה חובה לפי חוק, אבל בלעדיו לא נוכל ליצור קשר או לתת גישה. המידע לא נמכר ולא מועבר לאף אחד. הוא נשמר בשרת של האתר, ויומן הכניסות נמחק אחרי חצי שנה.</p>
<h2>הזכויות שלך</h2>
<p>אפשר לבקש לעיין במידע, לתקן או למחוק אותו, או להסיר את עצמך מהרשימה בכל רגע. כותבים לכתובת שלמעלה, או לוחצים על קישור ההסרה שבכל הודעה.</p>
<h2 id="a11y">הצהרת נגישות</h2>
<p>אנחנו שואפים שהאתר יעמוד בתקן הישראלי 5568 (WCAG 2.0 ברמה AA). יש בו ניווט מלא במקלדת, תיוג לקוראי מסך וניגודיות קריאה. בקורא אפשר להגדיל את הטקסט, והאתר מכבד את הגדרת "הפחתת תנועה". אם משהו לא נוח או לא נגיש, כתבו ל־<a href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?></a> ונתקן.</p>
<?php endif; ?>
</main>
</body>
</html>
