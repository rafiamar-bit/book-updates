<?php
/**
 * File: templates/reader.php
 * The reader shell. It holds no book text: chapters arrive one at a time from the server
 * (assets/reader.js -> admin-ajax rpb_chapter) only for a valid reader session.
 *
 * @var array $reader  from RPB_Access::current()
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s     = RPB_Settings::all();
$inv   = $reader['invite'];
$books = array();
foreach ( $reader['langs'] as $l ) {
	$m = RPB_DB::meta( $l );
	if ( ! $m ) {
		continue;
	}
	$toc = array_map(
		function ( $r ) {
			return array( 'pos' => (int) $r['pos'], 'key' => $r['ckey'], 'kind' => $r['kind'], 'part' => $r['part'], 'title' => $r['title'], 'words' => (int) $r['words'] );
		},
		RPB_DB::toc( $l )
	);
	$books[ $l ] = array(
		'title'   => $m['title'] ? $m['title'] : RPB_Front::book_title( $l ),
		'author'  => $m['author'] ? $m['author'] : ( 'en' === $l ? $s['author_en'] : $s['author_he'] ),
		'dir'     => $m['dir'],
		'version' => $m['version'],
		'updated' => (int) $m['generated_ts'],
		'note'    => (string) $m['note'],
		'cover'   => ( RPB_Front::has_cover( $l ) || RPB_Front::has_cover( 'he' === $l ? 'en' : 'he' ) ) ? RPB_Front::cover_url( $l ) : '',
		'toc'     => $toc,
		'maxPos'  => $inv ? RPB_DB::max_pos( $l, $inv['max_chapters'] ) : -1,
	);
}
$progress = $inv ? json_decode( (string) $inv['progress'], true ) : array();
$start    = ( $progress['last'] ?? '' );
if ( ! isset( $books[ $start ] ) ) {
	$start = ( $inv && 'en' === $inv['lang'] && isset( $books['en'] ) ) ? 'en' : array_key_first( $books );
}
$cfg = array(
	'ajax'      => admin_url( 'admin-ajax.php' ),
	't'         => RPB_Access::csrf( $reader ),
	'langs'     => array_keys( $books ),
	'start'     => $start,
	'books'     => $books,
	'name'      => $reader['preview'] ? '' : (string) $reader['name'],
	'preview'   => (bool) $reader['preview'],
	'protect'   => (bool) $s['protect_copy'],
	'watermark' => (bool) $s['watermark'],
	'progress'  => is_array( $progress ) ? $progress : array(),
	'seen'      => $inv ? (string) $inv['seen_version'] : '',
	'landing'   => RPB_Settings::book_url( array( 'landing' => 1 ) ),
	'logout'    => RPB_Settings::book_url( array( 'logout' => 1 ) ),
	'uid'       => $inv ? (int) $inv['id'] : 0,
);
$b0 = $books[ $start ];
?><!doctype html>
<html lang="<?php echo esc_attr( $start ); ?>" dir="<?php echo esc_attr( $b0['dir'] ); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noimageindex, notranslate, noai, noimageai">
<meta name="googlebot" content="noindex, nofollow, noarchive, nosnippet">
<meta name="referrer" content="no-referrer">
<meta name="google" content="notranslate">
<meta name="theme-color" content="#fbf8f2">
<title><?php echo esc_html( $b0['title'] ); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Frank+Ruhl+Libre:wght@400;500;700&family=David+Libre:wght@400;500&family=Heebo:wght@400;500&family=EB+Garamond:ital,wght@0,400;0,500;1,400&family=Source+Sans+3:ital,wght@0,400;0,500;1,400&family=Bellefair&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( RPB_URL . 'assets/reader.css?v=' . RPB_VERSION ); ?>">
</head>
<body class="notranslate<?php echo $s['protect_copy'] ? ' protect' : ''; ?>" translate="no">
<div id="progress" aria-hidden="true"><i></i></div>
<header id="bar">
	<button id="tocBtn" class="ic" type="button" data-t-title="toc"><svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg></button>
	<div class="chap" id="chap"></div>
	<div class="grp">
		<button id="noteBtn" class="ic" type="button" data-t-title="note"><svg viewBox="0 0 24 24"><path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 013 3L8 19z M14 7l3 3"/></svg></button>
		<button id="langBtn" class="txt" type="button" hidden></button>
		<button id="setBtn" class="ic" type="button" data-t-title="settings"><svg viewBox="0 0 24 24"><path d="M5 18L10 6l5 12M7 14h6M16 18l2.5-6 2.5 6M17 16.5h3"/></svg></button>
	</div>
</header>

<div id="settings" class="pop" hidden>
	<div class="row"><span data-t="size"></span><div class="seg"><button id="fsDown" type="button">A−</button><button id="fsUp" type="button">A+</button></div></div>
	<div class="row"><span data-t="font"></span><div class="seg" id="fontSeg"><button data-font="serif" type="button"></button><button data-font="sans" type="button"></button></div></div>
	<div class="row"><span data-t="light"></span><div class="seg" id="themeSeg"><button data-theme="light" type="button"></button><button data-theme="sepia" type="button"></button><button data-theme="dark" type="button"></button></div></div>
	<div class="row foot"><a id="logoutLink" data-t="logout" href="#"></a></div>
</div>

<nav id="toc" aria-hidden="true">
	<div class="toc-head"><div class="toc-cover"><img id="tocCover" alt="" draggable="false"></div><div><b id="tocTitle"></b><span id="tocAuthor"></span><span id="tocPct"></span></div></div>
	<div id="tocList"></div>
</nav>
<div id="scrim" hidden></div>

<main id="vp">
	<div id="book" aria-live="polite"></div>
	<div id="wm" aria-hidden="true"></div>
	<div id="loading"><span></span></div>
</main>

<footer id="foot">
	<button id="prev" class="ic" type="button"><svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg></button>
	<div class="mid">
		<input id="slider" type="range" min="1" max="1" value="1">
		<div class="info"><span id="pn"></span><span id="pct"></span></div>
	</div>
	<button id="next" class="ic" type="button"><svg viewBox="0 0 24 24"><path d="M15 6l-6 6 6 6"/></svg></button>
</footer>

<div id="toast" role="status" hidden><div class="toast-in"><b id="toastTitle"></b><p id="toastBody"></p><button id="toastClose" type="button"></button></div></div>

<dialog id="noteDlg">
	<form method="dialog" id="noteForm">
		<h2 data-t="noteTitle"></h2>
		<p class="where" id="noteWhere"></p>
		<textarea id="noteBody" rows="7" required></textarea>
		<div class="acts"><button value="cancel" type="button" id="noteCancel" data-t="cancel"></button><button id="noteSend" class="pri" type="submit" data-t="send"></button></div>
		<p class="sent" id="noteSent" hidden data-t="thanks"></p>
	</form>
</dialog>

<noscript><p style="padding:40px;text-align:center">JavaScript is required to read this book.</p></noscript>
<script>window.RPB=<?php echo wp_json_encode( $cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ); ?>;</script>
<script src="<?php echo esc_url( RPB_URL . 'assets/reader.js?v=' . RPB_VERSION ); ?>"></script>
</body>
</html>
