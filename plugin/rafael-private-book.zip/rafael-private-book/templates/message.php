<?php
/**
 * File: templates/message.php
 * Friendly stop pages: wrong/revoked/expired link, device limit, AI crawler, no book uploaded yet.
 *
 * @var string $code
 * @var string $lang
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$en  = ( 'en' === $lang );
$T   = function ( $he, $e ) use ( $en ) { return $en ? $e : $he; };
$msg = array(
	'missing' => array( $T( 'הקישור הזה לא מוכר', 'This link isn\'t recognised' ), $T( 'כדאי לבדוק שהעתקת את כל הקישור. אם הבעיה נמשכת, אפשר לבקש קישור חדש.', 'Check that you copied the whole link. If it still doesn\'t work, you can ask for a new one.' ) ),
	'revoked' => array( $T( 'הקישור הזה כבר לא פעיל', 'This link is no longer active' ), $T( 'אם זו טעות, כדאי לפנות לרפאל ולבקש קישור חדש.', 'If that\'s a mistake, ask Rafael for a new link.' ) ),
	'expired' => array( $T( 'תוקף הקישור הסתיים', 'This link has expired' ), $T( 'אפשר לבקש מרפאל להאריך אותו.', 'You can ask Rafael to extend it.' ) ),
	'limit'   => array( $T( 'הקישור כבר פתוח במספר המכשירים המרבי', 'This link is already open on the maximum number of devices' ), $T( 'כל קישור אישי נפתח במספר מוגבל של מכשירים. אם החלפת טלפון או מחשב, רפאל יכול לאפס את המכשירים.', 'Each personal link opens on a limited number of devices. If you changed phone or computer, Rafael can reset them.' ) ),
	'blocked' => array( $T( 'הגישה חסומה', 'Access blocked' ), $T( 'הספר הזה לא זמין לסריקה או לבינה מלאכותית.', 'This book is not available to crawlers or AI.' ) ),
	'empty'   => array( $T( 'הספר עוד לא הועלה', 'The book hasn\'t been uploaded yet' ), $T( 'נסו שוב בעוד כמה דקות.', 'Please try again in a few minutes.' ) ),
);
$m = $msg[ $code ] ?? $msg['missing'];
?><!doctype html>
<html lang="<?php echo $en ? 'en' : 'he'; ?>" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noai, noimageai">
<title><?php echo esc_html( $m[0] ); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Karantina:wght@300;400;700&family=Big+Shoulders+Display:wght@300;800;900&family=Noto+Serif+Hebrew:wght@300;400;600&family=JetBrains+Mono:wght@400;600&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( RPB_URL . 'assets/landing.css?v=' . RPB_VERSION ); ?>">
<style>.solo{min-height:100svh;display:grid;place-items:center;padding:40px var(--gut);text-align:center}.solo h1{font-family:var(--display);font-weight:400;font-size:clamp(30px,3vw + 14px,48px);line-height:1.15;margin:0 0 14px}.solo p{color:#cfc7ba;max-width:42ch;margin:0 auto 28px}.tri{font-size:40px;color:var(--pink);margin-bottom:18px}</style>
</head>
<body class="<?php echo $en ? 'en' : 'he'; ?>">
<main class="solo"><div>
	<div class="tri" aria-hidden="true">△</div>
	<h1><?php echo esc_html( $m[0] ); ?></h1>
	<p><?php echo esc_html( $m[1] ); ?></p>
	<?php if ( 'blocked' !== $code ) : ?><a class="btn ghost" href="<?php echo esc_url( RPB_Settings::book_url( $en ? array( 'lang' => 'en', 'landing' => 1 ) : array( 'landing' => 1 ) ) ); ?>#invite"><?php echo esc_html( $T( 'לעמוד הספר', 'To the book\'s page' ) ); ?></a><?php endif; ?>
</div></main>
</body>
</html>
