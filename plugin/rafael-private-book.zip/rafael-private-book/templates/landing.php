<?php
/**
 * File: templates/landing.php
 * The book's public landing page, Hebrew (RTL) and English (LTR). Design "Two timelines":
 * a split screen (warm ▲ half, cold △ half) with a ruler seam that follows the pointer,
 * a 02:00 chat moment, the two choices side by side, the blurb, launch pre-registration,
 * early-reader access and FAQ. Never contains any of the book's text.
 *
 * @var string $lang     'he' | 'en'
 * @var bool   $is_home
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$s      = RPB_Settings::all();
$en     = ( 'en' === $lang );
$T      = function ( $he, $e ) use ( $en ) { return $en ? $e : $he; };
$title  = RPB_Front::book_title( $lang );
$author = $en ? $s['author_en'] : $s['author_he'];
$tag    = $en ? $s['tagline_en'] : $s['tagline_he'];
$brow   = $en ? $s['eyebrow_en'] : $s['eyebrow_he'];
$blurb  = array_values( array_filter( array_map( 'trim', preg_split( "/\n\s*\n/", (string) ( $en ? $s['blurb_en'] : $s['blurb_he'] ) ) ) ) );
$quotes = array();
foreach ( preg_split( "/\n/", (string) ( $en ? $s['quotes_en'] : $s['quotes_he'] ) ) as $q ) {
	$q = trim( $q );
	if ( $q ) {
		$p        = array_map( 'trim', explode( '|', $q, 2 ) );
		$quotes[] = array( $p[0], $p[1] ?? '' );
	}
}
// Title split in two words for the two halves ("חצי" | "סנטימטר", "Half an" | "Inch").
$words = preg_split( '/\s+/u', trim( $title ) );
$w2    = count( $words ) > 1 ? array_pop( $words ) : '';
$w1    = implode( ' ', $words );
$cover   = RPB_Front::has_cover( $lang ) || RPB_Front::has_cover( $en ? 'he' : 'en' ) ? RPB_Front::cover_url( $lang ) : '';
$dress   = RPB_URL . 'assets/dress.webp?v=' . RPB_VERSION;
$action  = RPB_Settings::book_url();
$sent    = isset( $_GET['sent'] ) ? sanitize_key( $_GET['sent'] ) : ''; // phpcs:ignore
$reader  = RPB_Access::current();
$other   = $en ? RPB_Settings::book_url( array( 'landing' => 1 ) ) : RPB_Settings::book_url( array( 'lang' => 'en', 'landing' => 1 ) );
$canon   = $is_home ? home_url( '/' ) : RPB_Settings::book_url( $en ? array( 'lang' => 'en' ) : array() );
$robots  = $s['landing_index'] ? 'index, follow, noarchive, noai, noimageai' : 'noindex, nofollow, noarchive, nosnippet, noai, noimageai';
$t0      = time();
$privacy_url  = RPB_Settings::book_url( $en ? array( 'privacy' => 1, 'lang' => 'en' ) : array( 'privacy' => 1 ) );
$privacy_line = $en
	? 'I have read the <a href="' . esc_url( $privacy_url ) . '" target="_blank">privacy policy</a>. My name and email are kept by Rafael Amar only to contact me about the book.'
	: 'קראתי את <a href="' . esc_url( $privacy_url ) . '" target="_blank">מדיניות הפרטיות</a>. השם והמייל נשמרים אצל רפאל עמר רק כדי ליצור איתי קשר לגבי הספר. מסירת המידע אינה חובה לפי חוק.';
$utm = '';
foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'ref' ) as $u ) {
	if ( ! empty( $_GET[ $u ] ) ) { // phpcs:ignore
		$utm .= '<input type="hidden" name="' . esc_attr( $u ) . '" value="' . esc_attr( substr( sanitize_text_field( wp_unslash( $_GET[ $u ] ) ), 0, 80 ) ) . '">'; // phpcs:ignore
	}
}
$faq = array();
foreach ( preg_split( "/\n/", (string) ( $en ? $s['faq_en'] : $s['faq_he'] ) ) as $q ) {
	$q = array_map( 'trim', explode( '|', $q, 2 ) );
	if ( '' !== $q[0] && ! empty( $q[1] ) ) {
		$faq[] = $q;
	}
}
$comps = $en ? $s['comps_en'] : $s['comps_he'];
$adult = $en ? $s['adult_en'] : $s['adult_he'];
// Physical halves: the hero is laid out left-to-right; in Hebrew the first word sits on the right.
$left_word  = $en ? $w1 : $w2;
$right_word = $en ? $w2 : $w1;
$a_txt = $T( 'הוא לוחץ.', 'He clicks.' );
$b_txt = $T( 'הוא לא לוחץ.', "He doesn't." );
?><!doctype html>
<html lang="<?php echo $en ? 'en' : 'he'; ?>" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?php echo esc_html( $title . ' · ' . $T( 'רומן מאת ', 'A novel by ' ) . $author ); ?></title>
<meta name="robots" content="<?php echo esc_attr( $robots ); ?>">
<meta name="description" content="<?php echo esc_attr( $brow . '. ' . $tag ); ?>">
<link rel="canonical" href="<?php echo esc_url( $canon ); ?>">
<meta property="og:type" content="book">
<meta property="og:title" content="<?php echo esc_attr( $title . ' · ' . $author ); ?>">
<meta property="og:description" content="<?php echo esc_attr( $tag ); ?>">
<?php if ( $cover ) : ?><meta property="og:image" content="<?php echo esc_url( $cover ); ?>"><meta name="twitter:card" content="summary_large_image"><?php endif; ?>
<meta name="theme-color" content="#07070a">
<link rel="preload" as="image" href="<?php echo esc_url( $dress ); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Karantina:wght@300;400;700&family=Big+Shoulders+Display:wght@300;800;900&family=Noto+Serif+Hebrew:wght@300;400;600&family=JetBrains+Mono:wght@400;600&family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,400;1,9..144,300&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( RPB_URL . 'assets/landing.css?v=' . RPB_VERSION ); ?>">
<style>.half .bgimg{background-image:url("<?php echo esc_url( $dress ); ?>"),repeating-linear-gradient(90deg,rgba(255,255,255,.035) 0 2px,transparent 2px 90px),linear-gradient(#1a2142,#05060c)}</style>
</head>
<body class="<?php echo $en ? 'en' : 'he'; ?>">

<header class="top mono" id="top">
	<a class="brand" href="#top"><?php echo esc_html( $author ); ?></a>
	<nav aria-label="<?php echo esc_attr( $T( 'ניווט', 'Navigation' ) ); ?>">
		<a href="#story"><?php echo esc_html( $T( 'הסיפור', 'The story' ) ); ?></a>
		<a href="#launch"><?php echo esc_html( $T( 'מחיר השקה', 'Launch price' ) ); ?></a>
		<a href="#invite"><?php echo esc_html( $T( 'קריאה מוקדמת', 'Early reading' ) ); ?></a>
		<a class="lang" href="<?php echo esc_url( $other ); ?>" hreflang="<?php echo $en ? 'he' : 'en'; ?>" aria-label="<?php echo $en ? 'לעבור לעברית' : 'Switch to English'; ?>"><span lang="he"<?php echo $en ? '' : ' class="on"'; ?>>עברית</span><span lang="en"<?php echo $en ? ' class="on"' : ''; ?>>English</span></a>
	</nav>
</header>

<main>
<section class="hero" id="hero" aria-label="<?php echo esc_attr( $title ); ?>">
	<div class="half w" aria-hidden="true"><div class="bgimg"></div></div>
	<div class="half c" aria-hidden="true"><div class="bgimg"></div></div>
	<div class="seam" aria-hidden="true"><span><?php echo esc_html( $T( '½ ס״מ', '½ INCH' ) ); ?></span></div>
	<h1 class="ttl" aria-label="<?php echo esc_attr( $title ); ?>">
		<span class="l" aria-hidden="true" data-m="<?php echo esc_attr( $en ? '1' : '2' ); ?>"><?php echo esc_html( $left_word ); ?></span>
		<span class="r" aria-hidden="true" data-m="<?php echo esc_attr( $en ? '2' : '1' ); ?>"><?php echo esc_html( $right_word ); ?></span>
	</h1>
	<p class="topline mono" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>"><?php echo esc_html( $brow ); ?> · <?php echo esc_html( $author ); ?></p>
	<div class="labels" aria-hidden="true">
		<div class="l"><span class="mono"><?php echo $en ? '▲' : '△'; ?></span><b dir="<?php echo $en ? 'ltr' : 'rtl'; ?>"><?php echo esc_html( $en ? $a_txt : $b_txt ); ?></b></div>
		<div class="r"><span class="mono"><?php echo $en ? '△' : '▲'; ?></span><b dir="<?php echo $en ? 'ltr' : 'rtl'; ?>"><?php echo esc_html( $en ? $b_txt : $a_txt ); ?></b></div>
	</div>
	<div class="ctas" dir="<?php echo $en ? 'ltr' : 'rtl'; ?>">
		<a class="btn solid" href="#launch"><?php echo esc_html( $T( 'לשריין מחיר השקה', 'Reserve the launch price' ) ); ?></a>
		<?php if ( $reader ) : ?>
			<a class="btn line" href="<?php echo esc_url( RPB_Settings::book_url() ); ?>"><?php echo esc_html( $T( 'להמשיך לקרוא', 'Continue reading' ) ); ?></a>
		<?php else : ?>
			<a class="btn line" href="#invite"><?php echo esc_html( $T( 'יש לי קישור אישי', 'I have a personal link' ) ); ?></a>
		<?php endif; ?>
	</div>
</section>

<section class="clock" aria-label="<?php echo esc_attr( $T( 'הרגע', 'The moment' ) ); ?>">
	<div class="t" aria-hidden="true">02:00<small><?php echo $en ? 'AM' : ''; ?></small></div>
	<p><?php echo esc_html( $T( 'צ\'אט · יוני 2000', 'Chat room · June 2000' ) ); ?></p>
	<div class="hook">&gt; <span><?php echo esc_html( $T( 'אני מחפשת מלאך', 'I\'m looking for an angel' ) ); ?></span><i aria-hidden="true"></i></div>
</section>

<section class="rows" id="fork">
	<div class="row w"><span class="mono">▲ · 02:00:01</span><h2><?php echo esc_html( $a_txt ); ?></h2><p><?php echo esc_html( $T( 'הוא לא פוגש את נוגה לעולם.', 'He never meets Noga.' ) ); ?></p></div>
	<div class="line" aria-hidden="true"></div>
	<div class="row c"><span class="mono">△ · 02:00:01</span><h2><?php echo esc_html( $b_txt ); ?></h2><p><?php echo esc_html( $T( 'הוא פוגש אותה. ואחר כך גם את לולה.', 'He meets her. And later, Lola.' ) ); ?></p></div>
	<p class="two"><?php echo esc_html( $T( 'שני קווי זמן. שני חיים שלמים. רק אחד מהם קרה באמת.', 'Two timelines. Two whole lives. Only one of them really happened.' ) ); ?></p>
</section>

<section class="blurb" id="story">
	<div class="side">
		<?php if ( $cover ) : ?>
			<img class="cov" src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( $T( 'כריכת הספר חצי סנטימטר: שמלה ורודה על קולב בארון חשוך', 'Cover of Half an Inch: a pink dress on a hanger in a dark closet' ) ); ?>" width="700" height="993" loading="lazy" draggable="false">
		<?php endif; ?>
		<p class="mono"><?php echo esc_html( $author ); ?><br><?php echo esc_html( $brow ); ?><br><?php echo esc_html( $T( 'בקרוב · מודפס ודיגיטלי', 'Coming soon · Print & ebook' ) ); ?></p>
	</div>
	<div class="copy">
		<p class="tag"><?php echo esc_html( $tag ); ?></p>
		<?php foreach ( $blurb as $i => $para ) : ?>
			<p<?php echo 1 === $i ? ' class="big"' : ''; ?>><?php echo esc_html( $para ); ?></p>
		<?php endforeach; ?>
		<?php if ( $comps || $adult ) : ?>
			<p class="fine"><?php echo esc_html( $comps ); ?><?php if ( $adult ) : ?><br><span class="age">18+</span> <?php echo esc_html( $adult ); ?><?php endif; ?></p>
		<?php endif; ?>
	</div>
</section>

<?php if ( $quotes ) : ?>
<section class="quotes">
	<?php foreach ( $quotes as $q ) : ?>
		<figure><blockquote><?php echo esc_html( $q[0] ); ?></blockquote><?php if ( $q[1] ) : ?><figcaption class="mono"><?php echo esc_html( $q[1] ); ?></figcaption><?php endif; ?></figure>
	<?php endforeach; ?>
</section>
<?php endif; ?>

<section class="launch" id="launch">
	<h2><?php echo esc_html( $T( 'מחיר השקה למי שנרשם עכשיו', 'A launch price for early readers' ) ); ?></h2>
	<p class="lede"><?php echo esc_html( $en ? $s['launch_en'] : $s['launch_he'] ); ?></p>
	<?php if ( 'launch' === $sent ) : ?>
		<div class="ok" role="status"><b><?php echo esc_html( $T( 'נרשמת. תודה!', 'You\'re on the list. Thank you!' ) ); ?></b> <?php echo esc_html( $T( 'נעדכן אותך ראשון כשהספר יוצא, עם מחיר ההשקה.', 'We\'ll tell you first when the book is out, with the launch price.' ) ); ?></div>
	<?php else : ?>
		<?php if ( 'busy' === $sent ) : ?><div class="err" role="alert"><?php echo esc_html( $T( 'היו הרבה הרשמות מהרשת הזאת בשעה האחרונה. נסו שוב בעוד שעה.', 'Too many sign-ups from this network in the last hour. Please try again in an hour.' ) ); ?></div><?php endif; ?>
		<?php if ( 'err' === $sent ) : ?><div class="err" role="alert"><?php echo esc_html( $T( 'משהו חסר. צריך שם, מייל, וסימון שקראת את מדיניות הפרטיות.', 'Something is missing: a name, an email, and the privacy box.' ) ); ?></div><?php endif; ?>
		<form class="signup" method="post" action="<?php echo esc_url( $action ); ?>">
			<input type="hidden" name="rpb_do" value="request"><input type="hidden" name="kind" value="launch">
			<input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>"><input type="hidden" name="t0" value="<?php echo (int) $t0; ?>">
			<div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
			<?php echo $utm; // phpcs:ignore ?>
			<div class="bar">
				<label><span class="sr"><?php echo esc_html( $T( 'שם פרטי', 'First name' ) ); ?></span><input name="name" required autocomplete="given-name" placeholder="<?php echo esc_attr( $T( 'שם פרטי', 'First name' ) ); ?>"></label>
				<label><span class="sr"><?php echo esc_html( $T( 'מייל', 'Email' ) ); ?></span><input name="email" type="email" required autocomplete="email" dir="ltr" placeholder="<?php echo esc_attr( $T( 'מייל', 'Email' ) ); ?>"></label>
				<button type="submit"><?php echo esc_html( $T( 'שמרו לי מקום', 'Save my place' ) ); ?></button>
			</div>
			<label class="check"><input type="checkbox" name="privacy" value="1" required><span><?php echo $privacy_line; // phpcs:ignore ?></span></label>
			<label class="check"><input type="checkbox" name="consent" value="1"><span><?php echo esc_html( $T( 'אני מסכים/ה לקבל מרפאל עמר דיוור ודברי פרסומת במייל על הספר "חצי סנטימטר", כולל הצעת מחיר השקה. אפשר להסיר את עצמי בכל רגע בלחיצה. (לא חובה)', 'I agree to receive emails from Rafael Amar about Half an Inch, including launch offers. Unsubscribe any time. (Optional)' ) ); ?></span></label>
		</form>
	<?php endif; ?>
</section>

<section class="invite" id="invite">
	<div class="inv">
		<h3><?php echo esc_html( $T( 'קיבלת קישור אישי?', 'Got a personal link?' ) ); ?></h3>
		<p><?php echo esc_html( $en ? $s['status_en'] : $s['status_he'] ); ?></p>
		<?php if ( $reader ) : ?>
			<a class="btn solid" href="<?php echo esc_url( RPB_Settings::book_url() ); ?>"><?php echo esc_html( $T( 'להמשיך לקרוא', 'Continue reading' ) ); ?></a>
		<?php else : ?>
			<form class="linkform" id="linkform" action="<?php echo esc_url( $action ); ?>" method="get">
				<label><span class="sr"><?php echo esc_html( $T( 'הדביקו כאן את הקישור שקיבלתם', 'Paste the link you received' ) ); ?></span><input name="k" id="linkin" required dir="ltr" autocomplete="off" placeholder="<?php echo esc_attr( $T( 'הדביקו כאן את הקישור', 'Paste your link here' ) ); ?>"></label>
				<button class="btn line" type="submit"><?php echo esc_html( $T( 'לפתוח את הספר', 'Open the book' ) ); ?></button>
			</form>
		<?php endif; ?>
	</div>
	<?php if ( $s['landing_requests'] ) : ?>
	<div class="inv">
		<h3><?php echo esc_html( $T( 'רוצה לקרוא לפני כולם?', 'Want to read it first?' ) ); ?></h3>
		<?php if ( 'access' === $sent ) : ?>
			<div class="ok" role="status"><?php echo esc_html( $T( 'הבקשה התקבלה. אם יתפנה מקום, הקישור יגיע אליך.', 'Request received. If a spot opens, your link will arrive.' ) ); ?></div>
		<?php else : ?>
			<?php if ( 'err' === $sent || 'busy' === $sent ) : ?><div class="err" role="alert"><?php echo esc_html( 'busy' === $sent ? $T( 'היו הרבה בקשות מהרשת הזאת בשעה האחרונה. נסו שוב בעוד שעה.', 'Too many requests from this network in the last hour. Please try again in an hour.' ) : $T( 'משהו חסר. צריך שם, מייל או טלפון, וסימון שקראת את מדיניות הפרטיות.', 'Something is missing: a name, an email or phone, and the privacy box.' ) ); ?></div><?php endif; ?>
			<p><?php echo esc_html( $T( 'מספר הקוראים המוקדמים מוגבל. ספרו לנו מי אתם, ואולי הקישור הבא יהיה שלכם.', 'Early readers are limited. Tell us who you are, and the next link might be yours.' ) ); ?></p>
			<form class="req" method="post" action="<?php echo esc_url( $action ); ?>">
				<input type="hidden" name="rpb_do" value="request"><input type="hidden" name="kind" value="access">
				<input type="hidden" name="lang" value="<?php echo esc_attr( $lang ); ?>"><input type="hidden" name="t0" value="<?php echo (int) $t0; ?>">
				<div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
				<?php echo $utm; // phpcs:ignore ?>
				<div class="two-col">
					<label><span><?php echo esc_html( $T( 'שם', 'Name' ) ); ?></span><input name="name" required></label>
					<label><span><?php echo esc_html( $T( 'מייל או טלפון', 'Email or phone' ) ); ?></span><input name="email" required dir="ltr"></label>
				</div>
				<label><span><?php echo esc_html( $T( 'כמה מילים עליך (לא חובה)', 'A few words about you (optional)' ) ); ?></span><textarea name="message" rows="3"></textarea></label>
				<label class="check"><input type="checkbox" name="privacy" value="1" required><span><?php echo $privacy_line; // phpcs:ignore ?></span></label>
				<button class="btn line" type="submit"><?php echo esc_html( $T( 'לבקש קישור', 'Request a link' ) ); ?></button>
			</form>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</section>

<?php if ( $faq ) : ?>
<section class="faq" id="faq">
	<h2 class="mono"><?php echo esc_html( $T( 'שאלות נפוצות', 'Questions' ) ); ?></h2>
	<?php foreach ( $faq as $f ) : ?>
		<details><summary><?php echo esc_html( $f[0] ); ?></summary><p><?php echo esc_html( $f[1] ); ?></p></details>
	<?php endforeach; ?>
</section>
<script type="application/ld+json"><?php echo wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map( function ( $f ) { return array( '@type' => 'Question', 'name' => $f[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $f[1] ) ); }, $faq ) ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ); ?></script>
<?php endif; ?>
</main>

<footer class="foot">
	<p class="foot-links mono"><a href="<?php echo esc_url( $privacy_url ); ?>"><?php echo esc_html( $T( 'מדיניות פרטיות', 'Privacy policy' ) ); ?></a> · <a href="<?php echo esc_url( $privacy_url ); ?>#a11y"><?php echo esc_html( $T( 'הצהרת נגישות', 'Accessibility' ) ); ?></a> · <a href="<?php echo esc_url( $other ); ?>" lang="<?php echo $en ? 'he' : 'en'; ?>"><?php echo $en ? 'עברית' : 'English'; ?></a></p>
	<p>© <?php echo esc_html( gmdate( 'Y' ) . ' ' . $author ); ?>. <?php echo esc_html( $T( 'כל הזכויות שמורות. אין להעתיק, לסרוק, לאנדקס או להשתמש בספר לאימון מערכות בינה מלאכותית.', 'All rights reserved. No copying, crawling, indexing or use for training AI systems.' ) ); ?></p>
</footer>
<script src="<?php echo esc_url( RPB_URL . 'assets/landing.js?v=' . RPB_VERSION ); ?>" defer></script>
</body>
</html>
