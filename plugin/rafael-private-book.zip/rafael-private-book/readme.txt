=== File: readme.txt — ספר פרטי – חצי סנטימטר (rafael-private-book) ===
Requires at least: 6.0
Requires PHP: 7.4
Version: 1.3.1
License: Proprietary, all rights reserved

A private digital-book reader for an unpublished novel, in Hebrew (RTL) and English.

* Readers get in only with a personal link. Each link can be revoked, given an expiry date, limited to a number of devices and limited to the first N chapters.
* The book text is stored only in a private database table. It never becomes a post, a media file, a feed, a REST item or a sitemap entry.
* Chapters are sent one at a time, and only to a valid signed session. Every response carries noindex/noai and no-store headers. Requests are rate limited.
* robots.txt and ai.txt block the known AI crawlers, and those crawlers get a 403 from the server.
* Deterrents: no text selection, copying or printing, the reader's name as a faint watermark, and an invisible per-reader fingerprint with a leak tracer in wp-admin.
* Updates reach readers immediately. A new book version comes in by upload in wp-admin, by an encrypted push from the build script, or by an hourly pull from a URL. Readers keep their place and see an "updated" notice.
* Landing page in HE and EN with launch-price pre-registration and early-reader requests (privacy notice plus a separate marketing consent). Also a privacy policy, an accessibility statement and an FAQ.
* Admin: readers and links (with WhatsApp/email sending), reading progress, notes to the author, the access log, update messages to all readers, CSV exports and settings.

Deleting the plugin removes all of its data. Deactivating it keeps the data.
