<?php
/**
 * File: uninstall.php
 * Runs only when the plugin is DELETED (not on deactivation): removes the book text, readers, log and settings.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
global $wpdb;
foreach ( array( 'chapters', 'invites', 'log', 'requests', 'notes' ) as $t ) {
	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'rpb_' . $t ); // phpcs:ignore
}
foreach ( array( 'rpb_settings', 'rpb_db_version', 'rpb_cookie_key', 'rpb_update_key', 'rpb_book_he', 'rpb_book_en', 'rpb_cover_he', 'rpb_cover_en', 'rpb_changelog', 'rpb_last_import', 'rpb_pull_state', 'rpb_notify_draft' ) as $o ) {
	delete_option( $o );
}
wp_clear_scheduled_hook( 'rpb_daily' );
wp_clear_scheduled_hook( 'rpb_pull' );
