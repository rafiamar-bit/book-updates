/* File: assets/admin.js — copy buttons and confirmations in the private book admin */
document.addEventListener('click', function (e) {
  var b = e.target.closest('[data-copy]');
  if (b) {
    var i = b.parentNode.querySelector('input'); i.select();
    (navigator.clipboard ? navigator.clipboard.writeText(i.value) : Promise.reject()).catch(function () { document.execCommand('copy'); });
    var t = b.textContent; b.textContent = '✓ הועתק'; setTimeout(function () { b.textContent = t; }, 1500);
    return;
  }
  var c = e.target.closest('button[data-confirm]');
  if (c && !window.confirm(c.getAttribute('data-confirm'))) e.preventDefault();
});
document.addEventListener('submit', function (e) {
  var f = e.target;
  if (f.dataset && f.dataset.confirm && !(e.submitter && e.submitter.name === 'save_only') && !window.confirm(f.dataset.confirm)) e.preventDefault();
});
