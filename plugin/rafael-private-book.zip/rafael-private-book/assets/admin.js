/* File: assets/admin.js — copy buttons and confirmations in the private book admin */
document.addEventListener('click', function (e) {
  var b = e.target.closest('[data-copy]');
  if (b) {
    var i = b.parentNode.querySelector('input'); i.select();
    (navigator.clipboard ? navigator.clipboard.writeText(i.value) : Promise.reject()).catch(function () { document.execCommand('copy'); });
    var t = b.textContent; b.textContent = '✓ הועתק'; setTimeout(function () { b.textContent = t; }, 1500);
    return;
  }
  var c = e.target.closest('button[data-confirm]');
  if (c && !window.confirm(c.getAttribute('data-confirm'))) e.preventDefault();
});
document.addEventListener('submit', function (e) {
  var f = e.target;
  if (f.dataset && f.dataset.confirm && !(e.submitter && e.submitter.name === 'save_only') && !window.confirm(f.dataset.confirm)) e.preventDefault();
});
/* sortable reader tables: click a header to sort, click again to reverse */
document.addEventListener('click', function (e) {
  var th = e.target.closest('table.rpb-sortable th[data-sort]');
  if (!th) return;
  var table = th.closest('table'), tb = table.tBodies[0], col = [].indexOf.call(th.parentNode.children, th);
  var desc = !(th.classList.contains('sorted') && th.classList.contains('desc'));
  if (th.classList.contains('sorted') && th.classList.contains('asc')) desc = true;
  else if (th.classList.contains('sorted') && th.classList.contains('desc')) desc = false;
  else desc = th.getAttribute('data-sort') === 'num'; // numbers start big-to-small, names A-Z
  [].forEach.call(th.parentNode.children, function (h) { h.classList.remove('sorted', 'asc', 'desc'); });
  th.classList.add('sorted', desc ? 'desc' : 'asc');
  var num = th.getAttribute('data-sort') === 'num';
  var rows = [].slice.call(tb.rows).filter(function (r) { return !r.classList.contains('empty'); });
  rows.sort(function (a, b) {
    var x = a.cells[col].getAttribute('data-v') || '', y = b.cells[col].getAttribute('data-v') || '';
    var c = num ? (parseFloat(x) || 0) - (parseFloat(y) || 0) : x.localeCompare(y, 'he');
    return desc ? -c : c;
  });
  rows.forEach(function (r) { tb.appendChild(r); });
});
