/* File: assets/reader.js
   Private book reader. Fetches one chapter at a time from the server, lays it out in book pages
   (CSS columns), remembers the place per language (this device + the server, so other devices too),
   shows "the book was updated" once per new version, lets the reader send a note to the author,
   and applies the deterrents (no select/copy/print, the reader's name as a faint watermark). */
(function () {
  'use strict';
  var C = window.RPB, root = document.documentElement, $ = function (id) { return document.getElementById(id); };
  var vp = $('vp'), book = $('book');

  var S = {
    he: { toc: 'תוכן העניינים', note: 'הערה לסופר', settings: 'תצוגה', size: 'גודל אות', font: 'גופן', light: 'תאורה',
      serif: 'ספר', sans: 'נקי', day: 'יום', sepia: 'ספיה', night: 'לילה', logout: 'יציאה מהספר במכשיר הזה',
      page: 'עמוד', of: 'מתוך', chapter: 'פרק', ofBook: 'מהספר', read: 'נקרא',
      noteTitle: 'הערה לרפאל', noteWhere: 'על', send: 'שליחה', cancel: 'ביטול', thanks: 'נשלח. תודה! כל הערה עוזרת לספר להיות טוב יותר.',
      updTitle: 'הספר עודכן', updBody: 'יש גרסה חדשה של הספר. המשכת בדיוק מאותו מקום.', ok: 'הבנתי',
      end: 'סוף', endNote: 'תודה שקראת. ספר/י לרפאל מה הרגשת.', endBtn: 'לכתוב לרפאל', session: 'הקישור כבר לא פעיל במכשיר הזה.',
      err: 'בעיה בטעינה. בודק שוב...', slow: 'רגע, לאט לאט...', locked: 'הפרק הזה עוד לא פתוח בקישור שלך. רוצה להמשיך? כתבו לרפאל.', other: 'English', hint: 'החלקה או לחיצה בצד מעבירות עמוד', personal: 'עותק אישי' },
    en: { toc: 'Contents', note: 'Note to the author', settings: 'Display', size: 'Text size', font: 'Typeface', light: 'Light',
      serif: 'Book', sans: 'Clean', day: 'Day', sepia: 'Sepia', night: 'Night', logout: 'Leave the book on this device',
      page: 'Page', of: 'of', chapter: 'Chapter', ofBook: 'of the book', read: 'read',
      noteTitle: 'A note to Rafael', noteWhere: 'About', send: 'Send', cancel: 'Cancel', thanks: 'Sent. Thank you! Every note makes the book better.',
      updTitle: 'The book was updated', updBody: 'There is a new version of the book. You are right where you left off.', ok: 'Got it',
      end: 'The End', endNote: 'Thank you for reading. Tell Rafael how it made you feel.', endBtn: 'Write to Rafael', session: 'This link is no longer active on this device.',
      err: 'Loading problem. Trying again...', slow: 'One moment...', locked: 'This chapter is not open on your link yet. Want more? Write to Rafael.', other: 'עברית', hint: 'Swipe or tap the side to turn the page', personal: 'Personal copy' }
  };

  var store = {
    get: function (k) { try { return localStorage.getItem('rpb-' + C.uid + '-' + k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem('rpb-' + C.uid + '-' + k, v); } catch (e) {} }
  };
  var SIZES = [15, 16, 17, 18, 19, 21, 23, 26, 29, 32];
  var fsi = +(store.get('fsi') || 4); if (!(fsi >= 0 && fsi < SIZES.length)) fsi = 4;
  var theme = store.get('theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  var font = store.get('font') || 'serif';

  var lang, B, T, totalWords = 0, before = [];
  var idx = 0, cur = 0, total = 1, K = 1, P = 1, W = 0, nodes = [], cache = {}, loadingIdx = -1;

  /* ---------- server ---------- */
  function post(action, data) {
    var fd = new FormData(); fd.append('action', action); fd.append('t', C.t); fd.append('lang', lang);
    for (var k in data) fd.append(k, data[k]);
    return fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin', cache: 'no-store' }).then(function (r) {
      if (r.status === 401) { sessionGone(); throw new Error('session'); }
      return r.json().then(function (j) { if (!r.ok || !j.ok) { var e = new Error(j.error || 'http'); e.status = r.status; throw e; } return j; });
    });
  }
  function getChapter(i, tries) {
    var key = lang + ':' + i;
    if (cache[key]) return Promise.resolve(cache[key]);
    return post('rpb_chapter', { pos: B.toc[i].pos }).then(function (j) {
      if (j.version !== B.version) { location.reload(); throw new Error('reload'); } // new version uploaded meanwhile
      cache[key] = j; return j;
    }).catch(function (e) {
      tries = tries || 0;
      if (e.message === 'session' || e.message === 'reload' || tries > 4) throw e;
      if (e.status === 429) toast(T.slow, '', 1500);
      return new Promise(function (res) { setTimeout(res, 1200 * (tries + 1)); }).then(function () { return getChapter(i, tries + 1); });
    });
  }
  function sessionGone() {
    book.innerHTML = '<div class="fin page">△<small>' + esc(T.session) + '</small></div>';
    setTimeout(function () { location.href = C.landing + '#invite'; }, 2500);
  }

  /* ---------- prefs ---------- */
  function applyPrefs() {
    root.dataset.theme = theme; root.dataset.font = font; root.style.setProperty('--fs', SIZES[fsi] + 'px');
    var tc = { light: '#fbf8f2', sepia: '#f0e4cd', dark: '#181614' }[theme];
    var m = document.querySelector('meta[name=theme-color]'); if (m) m.content = tc;
    [].forEach.call(document.querySelectorAll('#themeSeg button'), function (b) { b.classList.toggle('on', b.dataset.theme === theme); });
    [].forEach.call(document.querySelectorAll('#fontSeg button'), function (b) { b.classList.toggle('on', b.dataset.font === font); });
    store.set('fsi', fsi); store.set('theme', theme); store.set('font', font);
  }
  function setLang(l) {
    lang = l; B = C.books[l]; T = S[l] || S.he;
    root.lang = l; root.dir = B.dir; document.title = B.title;
    totalWords = 0; before = [];
    B.toc.forEach(function (c) { before.push(totalWords); totalWords += Math.max(1, c.words); });
    [].forEach.call(document.querySelectorAll('[data-t]'), function (el) { el.textContent = T[el.dataset.t] || ''; });
    [].forEach.call(document.querySelectorAll('[data-t-title]'), function (el) { el.title = T[el.dataset.tTitle]; el.setAttribute('aria-label', T[el.dataset.tTitle]); });
    $('prev').setAttribute('aria-label', l === 'en' ? 'Previous page' : 'עמוד קודם');
    $('next').setAttribute('aria-label', l === 'en' ? 'Next page' : 'עמוד הבא');
    $('slider').setAttribute('aria-label', l === 'en' ? 'Position in the chapter' : 'מיקום בפרק');
    $('fontSeg').children[0].textContent = T.serif; $('fontSeg').children[1].textContent = T.sans;
    var ts = $('themeSeg').children; ts[0].textContent = T.day; ts[1].textContent = T.sepia; ts[2].textContent = T.night;
    var lb = $('langBtn'); if (C.langs.length > 1) { lb.hidden = false; lb.textContent = T.other; lb.lang = l === 'he' ? 'en' : 'he'; }
    $('tocTitle').textContent = B.title; $('tocAuthor').textContent = B.author;
    if (B.cover) { $('tocCover').src = B.cover; } else { $('tocCover').parentNode.style.display = 'none'; }
    watermark(); buildToc();
  }

  /* ---------- watermark ---------- */
  function watermark() {
    var wm = $('wm');
    if (!C.watermark || !C.name) { wm.style.display = 'none'; return; }
    var txt = (T.personal + ' · ' + C.name).replace(/[<&>"]/g, '');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="360" height="220"><text x="20" y="130" transform="rotate(-24 180 110)" font-family="sans-serif" font-size="17" fill="#000">' + txt + '</text></svg>';
    wm.style.backgroundImage = 'url("data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg) + '")';
  }

  /* ---------- layout ---------- */
  function pageOf(el) {
    var br = book.getBoundingClientRect(), r = el.getBoundingClientRect();
    return B.dir === 'rtl' ? Math.max(0, Math.floor((br.right - r.right + 1) / P)) : Math.max(0, Math.floor((r.left - br.left + 1) / P));
  }
  function layout(keepNode) {
    var vw = innerWidth; K = vw >= 1100 ? 2 : 1;
    W = Math.floor(K === 2 ? Math.min(vw - 48, 1400) : Math.min(vw - 16, 760));
    var pad = K === 2 ? 48 : (W < 520 ? 20 : 40); P = W / K;
    vp.classList.toggle('spread', K === 2);
    vp.style.width = W + 'px'; vp.style.left = Math.floor((vw - W) / 2) + 'px';
    var H = vp.clientHeight; root.style.setProperty('--H', H + 'px');
    book.style.width = W + 'px'; book.style.padding = '26px ' + pad + 'px';
    book.style.columnWidth = ((W - 2 * K * pad) / K) + 'px'; book.style.columnGap = (2 * pad) + 'px';
    book.classList.add('noanim'); book.style.transform = 'none';
    var end = $('end'); total = end ? pageOf(end) + 1 : 1;
    $('slider').max = total;
    if (keepNode != null && nodes[keepNode]) cur = pageOf(nodes[keepNode]);
    go(cur, true);
    requestAnimationFrame(function () { requestAnimationFrame(function () { book.classList.remove('noanim'); }); });
  }
  function go(p, instant) {
    cur = Math.max(0, Math.min(total - 1, p)); cur -= cur % K;
    book.style.transform = 'translateX(' + (B.dir === 'rtl' ? cur * P : -cur * P) + 'px)';
    var c = B.toc[idx];
    var pg = K === 2 && cur + 2 <= total ? (cur + 1) + '–' + (cur + 2) : (cur + 1);
    $('pn').textContent = T.page + ' ' + pg + ' ' + T.of + ' ' + total;
    $('slider').value = cur + 1;
    var pct = bookPct();
    $('pct').textContent = Math.floor(pct) + '% ' + T.ofBook;
    $('progress').firstChild.style.width = pct + '%';
    $('tocPct').textContent = Math.floor(pct) + '% ' + T.read;
    $('chap').textContent = c.kind === 'front' ? B.title : c.title;
    if (!instant) saveSoon();
  }
  function chapLabel(i) { var n = 0; for (var j = 0; j <= i; j++) if (B.toc[j].kind !== 'front') n++; return T.chapter + ' ' + n + '/' + B.toc.filter(function (x) { return x.kind !== 'front'; }).length; }
  function frac() {
    if (!nodes.length || total <= 1) return cur > 0 ? 1 : 0;
    var lo = 0, hi = nodes.length - 1, ans = 0;
    while (lo <= hi) { var m = (lo + hi) >> 1; if (pageOf(nodes[m]) >= cur) { ans = m; hi = m - 1; } else lo = m + 1; }
    return ans / nodes.length;
  }
  function bookPct() {
    var c = B.toc[idx], f = total > 1 ? cur / (total - 1) : 1;
    return Math.min(100, (before[idx] + f * Math.max(1, c.words)) / totalWords * 100);
  }

  /* ---------- chapters ---------- */
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function allowed(i) { return B.maxPos < 0 || B.toc[i].pos <= B.maxPos; }
  function show(i, where) { // where: 'start' | 'end' | {frac}
    if (i < 0 || i >= B.toc.length) return;
    if (!allowed(i)) { toast(T.locked, '', 0, T.ok); return; }
    loadingIdx = i; $('loading').classList.add('on');
    var t0 = setTimeout(function () { $('loading').classList.add('on'); }, 150);
    getChapter(i).then(function (ch) {
      if (loadingIdx !== i) return;
      clearTimeout(t0); $('loading').classList.remove('on');
      book.classList.add('fading');
      setTimeout(function () {
        idx = i;
        var h = '';
        if (ch.kind === 'front' && B.cover) h += '<div class="cover page"><img src="' + esc(B.cover) + '" alt="" draggable="false"></div>';
        if (ch.part) h += '<h1 class="part page">' + esc(ch.part) + '</h1>';
        h += ch.html;
        if (i + 1 < B.toc.length && !allowed(i + 1)) h += '<div class="fin page">△<small>' + esc(T.locked) + '</small><button type="button" id="endNote">' + esc(T.endBtn) + '</button></div>';
        if (i === B.toc.length - 1) h += '<div class="fin page">' + esc(T.end) + '<small>' + esc(T.endNote) + '</small><button type="button" id="endNote">' + esc(T.endBtn) + '</button></div>';
        h += '<div id="end"></div>';
        book.innerHTML = h;
        nodes = [].slice.call(book.querySelectorAll('p,h1,h2,.page,hr'));
        var keep = null; cur = 0;
        if (where === 'end') cur = 1e9;
        else if (where && typeof where.frac === 'number') keep = Math.min(nodes.length - 1, Math.round(where.frac * nodes.length));
        layout(keep);
        book.classList.remove('fading');
        markToc(); saveSoon();
        var en = $('endNote'); if (en) en.onclick = openNote;
        [].forEach.call(book.querySelectorAll('img'), function (im) { im.addEventListener('load', function () { layout(currentNode()); }, { once: true }); });
        if (i + 1 < B.toc.length && allowed(i + 1)) setTimeout(function () { getChapter(i + 1).catch(function () {}); }, 800); // prefetch
      }, 160);
    }).catch(function (e) {
      $('loading').classList.remove('on');
      if (e.message !== 'session' && e.message !== 'reload') toast(T.err, '', 2500);
    });
  }
  function currentNode() { return nodes.length ? Math.round(frac() * nodes.length) : null; }
  function next() { if (cur + K < total) go(cur + K); else if (idx + 1 < B.toc.length) show(idx + 1, 'start'); }
  function prev() { if (cur > 0) go(cur - K); else if (idx > 0) show(idx - 1, 'end'); }

  /* ---------- position ---------- */
  var st, srv;
  function saveSoon() { clearTimeout(st); st = setTimeout(saveNow, 250); }
  function saveNow() {
    if (!B) return;
    var c = B.toc[idx], pos = { key: c.key, frac: +frac().toFixed(4), at: Date.now() };
    store.set('pos-' + lang, JSON.stringify(pos)); store.set('lang', lang);
    clearTimeout(srv);
    srv = setTimeout(function () {
      if (C.preview) return;
      post('rpb_progress', { key: c.key, title: c.title, frac: pos.frac, pct: bookPct().toFixed(1) }).catch(function () {});
    }, 2500);
  }
  function startPosition() {
    var local = null; try { local = JSON.parse(store.get('pos-' + lang) || 'null'); } catch (e) {}
    var server = C.progress && C.progress[lang];
    var p = local;
    if (server && server.key && (!local || (server.at * 1000) > (local.at || 0) + 60000)) p = { key: server.key, frac: server.frac }; // read further on another device
    var i = 0;
    if (p) { for (var j = 0; j < B.toc.length; j++) if (B.toc[j].key === p.key) { i = j; break; } }
    if (!allowed(i)) { i = 0; p = null; }
    return { i: i, frac: p ? p.frac : 0 };
  }
  addEventListener('pagehide', saveNow);
  document.addEventListener('visibilitychange', function () { if (document.hidden) saveNow(); });

  /* ---------- table of contents ---------- */
  function buildToc() {
    var list = $('tocList'); list.innerHTML = '';
    var maxPct = C.progress && C.progress[lang] ? C.progress[lang].max || 0 : 0;
    B.toc.forEach(function (c, i) {
      if (c.part) { var pt = document.createElement('div'); pt.className = 'part'; pt.textContent = c.part; list.appendChild(pt); }
      var a = document.createElement('a'); a.href = '#'; a._i = i;
      var t = document.createElement('span'); t.textContent = c.kind === 'front' ? B.title : c.title; a.appendChild(t);
      var endPct = (before[i] + Math.max(1, c.words)) / totalWords * 100;
      if (!allowed(i)) { var lk = document.createElement('span'); lk.className = 'done'; lk.textContent = '🔒'; a.appendChild(lk); a.classList.add('locked'); }
      else if (endPct <= maxPct + 0.01) { var d = document.createElement('span'); d.className = 'done'; d.textContent = '✓'; a.appendChild(d); }
      a.onclick = function (e) { e.preventDefault(); closeAll(); show(i, 'start'); };
      list.appendChild(a);
    });
    markToc();
  }
  function markToc() {
    [].forEach.call(document.querySelectorAll('#tocList a'), function (a) {
      a.classList.toggle('cur', a._i === idx);
      if (a._i === idx && $('toc').classList.contains('open')) a.scrollIntoView({ block: 'center' });
    });
  }

  /* ---------- UI ---------- */
  function closeAll() { $('toc').classList.remove('open'); $('toc').setAttribute('aria-hidden', 'true'); $('settings').hidden = true; $('scrim').hidden = true; }
  $('tocBtn').onclick = function () { var o = !$('toc').classList.contains('open'); closeAll(); if (o) { $('toc').classList.add('open'); $('toc').setAttribute('aria-hidden', 'false'); $('scrim').hidden = false; markToc(); } };
  $('setBtn').onclick = function () { var o = $('settings').hidden; closeAll(); $('settings').hidden = !o; };
  $('scrim').onclick = closeAll;
  $('next').onclick = next; $('prev').onclick = prev;
  $('slider').oninput = function (e) { go(+e.target.value - 1); };
  var rl; function relayout() { clearTimeout(rl); var keep = currentNode(); rl = setTimeout(function () { layout(keep); }, 80); }
  $('fsUp').onclick = function () { fsi = Math.min(SIZES.length - 1, fsi + 1); applyPrefs(); relayout(); };
  $('fsDown').onclick = function () { fsi = Math.max(0, fsi - 1); applyPrefs(); relayout(); };
  [].forEach.call(document.querySelectorAll('#fontSeg button'), function (b) { b.onclick = function () { font = b.dataset.font; applyPrefs(); relayout(); }; });
  [].forEach.call(document.querySelectorAll('#themeSeg button'), function (b) { b.onclick = function () { theme = b.dataset.theme; applyPrefs(); }; });
  $('logoutLink').href = C.logout;
  $('langBtn').onclick = function () {
    saveNow(); var to = lang === 'he' ? 'en' : 'he'; if (!C.books[to]) return;
    setLang(to); var sp = startPosition(); show(sp.i, { frac: sp.frac }); checkUpdate();
  };
  vp.addEventListener('click', function (e) {
    if (e.target.closest('button,a')) return;
    if (!$('settings').hidden || $('toc').classList.contains('open')) { closeAll(); return; }
    var r = vp.getBoundingClientRect(), x = (e.clientX - r.left) / r.width;
    var fwdLeft = B.dir === 'rtl';
    if (x < 0.38) { fwdLeft ? next() : prev(); } else if (x > 0.62) { fwdLeft ? prev() : next(); }
  });
  document.addEventListener('keydown', function (e) {
    if ($('noteDlg').open) return;
    var k = e.key, rtl = B.dir === 'rtl';
    if (k === 'Escape') { closeAll(); return; }
    if (k === 'PageDown' || k === ' ' || (k === 'ArrowLeft' && rtl) || (k === 'ArrowRight' && !rtl)) { e.preventDefault(); next(); }
    else if (k === 'PageUp' || (k === 'ArrowRight' && rtl) || (k === 'ArrowLeft' && !rtl)) { e.preventDefault(); prev(); }
    else if (k === 'Home') go(0); else if (k === 'End') go(total - 1);
  });
  var tx = null, ty = null, tt = 0;
  vp.addEventListener('touchstart', function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; tt = Date.now(); }, { passive: true });
  vp.addEventListener('touchend', function (e) {
    if (tx == null) return; var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty; tx = null;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.2 && Date.now() - tt < 800) {
      e.preventDefault(); var rtl = B.dir === 'rtl'; (dx > 0) === rtl ? next() : prev();
    }
  });
  addEventListener('resize', relayout);

  /* ---------- toast & updates ---------- */
  var toastT;
  function toast(title, body, ms, btn) {
    $('toastTitle').textContent = title; $('toastBody').textContent = body || ''; $('toastBody').hidden = !body;
    $('toastClose').textContent = btn || T.ok; $('toastClose').hidden = !btn && !!ms;
    $('toast').hidden = false; clearTimeout(toastT);
    if (ms) toastT = setTimeout(function () { $('toast').hidden = true; }, ms);
  }
  $('toastClose').onclick = function () { $('toast').hidden = true; };
  function checkUpdate() {
    var seenLocal = store.get('ver-' + lang);
    var seenServer = (C.seen || '').indexOf(lang + ':') === 0 ? C.seen.slice(lang.length + 1) : '';
    var seen = seenLocal || seenServer;
    if (seen && seen !== B.version && !C.preview) {
      var d = B.updated ? new Date(B.updated * 1000).toLocaleDateString(lang === 'he' ? 'he-IL' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' }) : '';
      toast(T.updTitle + (d ? ' · ' + d : ''), (B.note ? B.note + '\n' : '') + T.updBody, 0, T.ok);
    }
    store.set('ver-' + lang, B.version);
  }

  /* ---------- note to the author ---------- */
  function openNote() {
    var c = B.toc[idx]; $('noteWhere').textContent = T.noteWhere + ': ' + (c.kind === 'front' ? B.title : c.title) + ' · ' + T.page + ' ' + (cur + 1);
    $('noteSent').hidden = true; $('noteSend').disabled = false; $('noteBody').value = store.get('draft') || '';
    if ($('noteDlg').showModal) $('noteDlg').showModal(); else $('noteDlg').setAttribute('open', '');
    setTimeout(function () { $('noteBody').focus(); }, 50);
  }
  $('noteBtn').onclick = openNote;
  $('noteCancel').onclick = function () { store.set('draft', $('noteBody').value); $('noteDlg').close(); };
  $('noteForm').addEventListener('submit', function (e) {
    e.preventDefault(); var body = $('noteBody').value.trim(); if (!body) return;
    var c = B.toc[idx]; $('noteSend').disabled = true;
    post('rpb_note', { body: body, key: c.key, title: c.title, page: cur + 1 }).then(function () {
      $('noteSent').hidden = false; $('noteBody').value = ''; store.set('draft', '');
      setTimeout(function () { $('noteDlg').close(); }, 1600);
    }).catch(function () { $('noteSend').disabled = false; toast(T.err, '', 2500); });
  });

  /* ---------- deterrents (they slow casual copying; nothing can stop a determined person) ---------- */
  if (C.protect) {
    ['copy', 'cut', 'contextmenu', 'dragstart', 'selectstart'].forEach(function (ev) {
      document.addEventListener(ev, function (e) { if (!e.target.closest || !e.target.closest('textarea')) e.preventDefault(); });
    });
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && /^[acspux]$/i.test(e.key) && !(e.target.closest && e.target.closest('textarea'))) e.preventDefault();
    }, true);
    addEventListener('beforeprint', function () { book.style.visibility = 'hidden'; });
    addEventListener('afterprint', function () { book.style.visibility = ''; });
  }

  /* ---------- start ---------- */
  applyPrefs();
  var q0 = null; try { q0 = new URLSearchParams(location.search).get('read'); } catch (e) {}
  if (q0) { try { history.replaceState(null, '', location.pathname); } catch (e) {} }
  var l0 = (q0 && C.books[q0]) ? q0 : store.get('lang'); setLang(C.books[l0] ? l0 : C.start);
  var sp = startPosition();
  show(sp.i, { frac: sp.frac });
  checkUpdate();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { if (nodes.length) layout(currentNode()); });
  if (!store.get('hinted')) { setTimeout(function () { if ($('toast').hidden) toast(T.hint, '', 3500); store.set('hinted', '1'); }, 1500); }
})();
