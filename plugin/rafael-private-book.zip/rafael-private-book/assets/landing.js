/* File: assets/landing.js
   Landing page behaviour ("Two timelines" design): solid top bar after scrolling, the seam between the two halves
   follows the pointer, and opening a pasted personal link. */
(function () {
  var top = document.getElementById('top');
  function onScroll() { if (top) top.classList.toggle('solid', window.scrollY > 40); }
  addEventListener('scroll', onScroll, { passive: true }); onScroll();

  // The seam (half a centimetre) moves toward the pointer, so one life grows while the other shrinks.
  var hero = document.getElementById('hero');
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (hero && !reduce && window.matchMedia && matchMedia('(hover: hover)').matches) {
    hero.addEventListener('pointermove', function (e) {
      if (innerWidth <= 760) return;
      var x = 50 + (e.clientX / innerWidth - 0.5) * 36;
      hero.style.setProperty('--split', x.toFixed(2) + '%');
    });
    hero.addEventListener('pointerleave', function () { hero.style.setProperty('--split', '50%'); });
  }

  // "Paste your link": accept the full link or just the code
  var lf = document.getElementById('linkform'), li = document.getElementById('linkin');
  if (lf && li) {
    lf.addEventListener('submit', function (e) {
      var v = (li.value || '').trim(), m = v.match(/[?&]k=([A-Za-z0-9_-]{16,})/);
      if (m) { li.value = m[1]; }
      else if (!/^[A-Za-z0-9_-]{16,}$/.test(v)) { e.preventDefault(); li.focus(); li.setCustomValidity(document.body.classList.contains('en') ? 'Please paste the full link you received' : 'צריך להדביק את הקישור המלא שקיבלת'); li.reportValidity(); }
    });
    li.addEventListener('input', function () { li.setCustomValidity(''); });
  }
  // No dragging or right-click saving of the images
  document.querySelectorAll('.cov').forEach(function (img) { img.addEventListener('contextmenu', function (e) { e.preventDefault(); }); });
})();
